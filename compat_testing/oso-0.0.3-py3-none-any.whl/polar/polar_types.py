from typing import Callable
from frozendict import frozendict

# FIXME: This is a bad name; rename. is_nontrivial_tuple_or_list
# is too long, but that's what it is. consp is only recognizable
# to a Lisper. is_descendable suggests its use, but is clumsy.
# Suggestions welcome.
def is_tuple(x):
    """Return true if x is a non-empty tuple or list.

    >>> is_tuple(())
    False
    >>> is_tuple(((),))
    True
    """
    return True if isinstance(x, (tuple, list)) and x else False

def is_dict(x):
    return isinstance(x, (dict, frozendict))

def map_tree(f: Callable, tree):
    """Copy a tree of tuples & dicts and apply f to the leaves.

    >>> map_tree(lambda x: x, ())
    ()
    >>> map_tree(lambda x: x + 1, (1, 1, (2, {3: (5, 8)})))
    (2, 2, (3, {3: (6, 9)}))
    """
    if tree == () or tree == [] or tree == {}:
        return tree
    elif is_tuple(tree):
        return copy_fact(tree, (map_tree(f, x) for x in tree))
    elif is_dict(tree):
        return copy_fact(tree, {k: map_tree(f, v) for k, v in tree.items()})
    elif hasattr(tree, "map"):
        # handles the Instance case
        return tree.map(f)
    else:
        return f(tree)

def copy_fact(fact, new_contents):
    """Copy a fact's Python type and attributes (especially "sig"),
    but with new contents."""
    copy = type(fact)(new_contents)
    if hasattr(fact, "__dict__"):
        for k, v in fact.__dict__.items():
            setattr(copy, k, v)
    if hasattr(fact, "code_context"):
        copy.code_context = fact.code_context
    return copy
