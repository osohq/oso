from polar.classes import Instance, make_instance
from polar.facts import Attr, Environment, Fact, Facts, EXTERNALS, external, external_lookup, make_env, tag, unify
from polar.parser import Variable

from dataclasses import asdict, dataclass, is_dataclass
from frozendict import frozendict
from typing import Tuple, Dict

@dataclass(frozen=True)
class Http:
    """A resource accessed via HTTP."""
    # Data fields.
    path: str = ""

    # Class variables.
    roles = ("client", "server")
    actions = ("get", "post", "delete")

#@external_lookup("httpToResource") see below
def external_resource_map(url, url_spec, result_kind, result_data_spec):
    if isinstance(result_data_spec, Instance):
        result_data_spec = result_data_spec.fields
    elif is_dataclass(result_data_spec):
        result_data_spec = asdict(result_data_spec)

    def is_pattern(s):
        return s and isinstance(s, str) and s[0] == "{" and s[-1] == "}"

    spec_fields = url_spec.split("/")
    url_fields = url.split("/")
    if len(spec_fields) != len(url_fields):
        return

    # Copy values that are just atoms.
    result_data = {k: v for k, v in result_data_spec.items() if not is_pattern(v)}

    for spec, url_part in zip(spec_fields, url_fields):
        if is_pattern(spec):
            for k, v in result_data_spec.items():
                if v == spec:
                    result_data[k] = url_part
            continue

        if spec != url_part:
            return

    # Replace unmatched keys with unbound variables
    for key in set(result_data_spec.keys()) - set(result_data.keys()):
        result_data[key] = Variable(result_data_spec[key][1:-1])

    yield make_instance(result_kind, **result_data)

# This is just so the tests can call the bare function above,
# and not have to go through the `external_lookup` interface.
httpToResource = external_lookup("httpToResource")(external_resource_map)
