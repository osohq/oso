"""Merkle tree storage with SQLite."""

from sqlite3 import Connection, IntegrityError

from .merkle import Leaf, Node

class MerkleDB:
    def __init__(self, db_filename):
        self.db = Connection(db_filename)
        self.db.execute("PRAGMA foreign_keys = ON;")
        self.db.execute("CREATE TABLE IF NOT EXISTS nodes "
                        "(sig NOT NULL PRIMARY KEY,"
                        " parent REFERENCES nodes,"
                        " data," # only non-NULL for leaves
                        " UNIQUE (parent, data));")
        self.db.execute("CREATE TABLE IF NOT EXISTS children "
                        "(parent NOT NULL REFERENCES nodes,"
                        " child NOT NULL REFERENCES nodes);")

    def close(self):
        self.db.close()

    def dump(self, root):
        """Dump a Merkle tree to the database."""
        with self.db as conn:
            c = conn.cursor()
            def insert(node):
                assert isinstance(node, (Leaf, Node))
                sig = node.sig
                parent = node.parent.sig if node.parent else None
                data = node.data if isinstance(node, Leaf) else None
                c.execute("INSERT INTO nodes (sig, parent, data) "
                          "VALUES (?, ?, ?) "
                          "ON CONFLICT (sig) DO NOTHING",
                          (sig, parent, data))
                if isinstance(node, Node):
                    for child in node:
                        insert(child)
                        c.execute("INSERT INTO children (parent, child) VALUES (?, ?)",
                                  (node.sig, child.sig))
            insert(root)
