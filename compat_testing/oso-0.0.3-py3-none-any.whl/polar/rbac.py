# AUTOMATICALLY GENERATED FILE. DO NOT EDIT.
'''Python interface classes for Polar 'rbac' module.'''

from .pymod import NamedFact
from dataclasses import dataclass
from typing import Tuple, Union

Expr = Union[str, Tuple]

@dataclass
class Actor(NamedFact):
    '''actor(?kind, ?name)'''
    kind: Expr
    name: Expr

@dataclass
class Action(NamedFact):
    '''action(?kind, ?name)'''
    kind: Expr
    name: Expr

@dataclass
class Resource(NamedFact):
    '''resource(?kind, ?data)'''
    kind: Expr
    data: Expr

@dataclass
class ResourceMapping(NamedFact):
    '''resourceMapping(?urlResource, ?dataResource)'''
    urlResource: Expr
    dataResource: Expr

@dataclass
class Relationship(NamedFact):
    '''relationship(?source, ?kind, ?target, ?role)'''
    source: Expr
    kind: Expr
    target: Expr
    role: Expr

@dataclass
class Role(NamedFact):
    '''role(resource(?kind, (?data,)), ?role)'''
    resource: Resource
    role: Expr

@dataclass
class Allow(NamedFact):
    '''allow(?actor, ?resource, ?action)'''
    actor: Expr
    resource: Expr
    action: Expr

@dataclass
class RbacAllow(NamedFact):
    '''rbacAllow(?actor, ?resource, ?action)'''
    actor: Expr
    resource: Expr
    action: Expr

@dataclass
class ActorAllowRule(NamedFact):
    '''actorAllowRule(?actor, ?resource, ?action)'''
    actor: Expr
    resource: Expr
    action: Expr

@dataclass
class MembersCanReadRepos(NamedFact):
    '''membersCanReadRepos(?actor, ?resource, ?action)'''
    actor: Expr
    resource: Expr
    action: Expr

@dataclass
class RepoInOrg(NamedFact):
    '''repoInOrg(?repo, ?org_1)'''
    repo: Expr
    org_1: Expr

@dataclass
class ActorInOrg(NamedFact):
    '''actorInOrg(?actor, ?org_2)'''
    actor: Expr
    org_2: Expr

@dataclass
class ActorInRole(NamedFact):
    '''actorInRole(?actor, ?role)'''
    actor: Expr
    role: Expr

@dataclass
class RbacAllowRule(NamedFact):
    '''rbacAllowRule(?role, ?resource, ?action)'''
    role: Expr
    resource: Expr
    action: Expr

@dataclass
class RoleRelationshipMapping(NamedFact):
    '''roleRelationshipMapping(?sourceResourceName, ?relationshipType, ?targetResourceName, ?roleName)'''
    sourceResourceName: Expr
    relationshipType: Expr
    targetResourceName: Expr
    roleName: Expr

@dataclass
class RelatedResourceRoleMapping(NamedFact):
    '''relatedResourceRoleMapping(?relationshipType, ?resourceName, ?resourceRole, ?roleName)'''
    relationshipType: Expr
    resourceName: Expr
    resourceRole: Expr
    roleName: Expr

@dataclass
class ResourceInRole(NamedFact):
    '''resourceInRole(resource(?resourceName, ?resourceNameData), role(resource(?resourceRole, ?resourceRoleData), ?roleName))'''
    resource: Resource
    role: Role

@dataclass
class ActorInRoleExternal(NamedFact):
    '''actorInRoleExternal(?actor, ?role)'''
    actor: Expr
    role: Expr

@dataclass
class ResourceMap(NamedFact):
    '''resourceMap(resource(?kind, (?url,)), ?result_resource)'''
    resource: Resource
    result_resource: Expr

@dataclass
class ExternalResourceMap(NamedFact):
    '''externalResourceMap(?url, ?url_spec, ?result_kind, ?result_data_spec, ?result_resource)'''
    url: Expr
    url_spec: Expr
    result_kind: Expr
    result_data_spec: Expr
    result_resource: Expr
