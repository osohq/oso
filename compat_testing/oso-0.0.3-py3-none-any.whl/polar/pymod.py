"""Generate Python interface classes for a knowledge base.

The idea is to turn a predicate `foo(?x)` into a dataclass
(a class with data fields) `Foo(x)`. If the argument is
structured, e.g., `foo(bar(?x))`, we generate a class `Bar`,
and type the `Foo.x` field as `Bar`.
"""

from dataclasses import fields
from pathlib import Path

from .facts import Fact

def polar_name(name):
    """Polar name from, e.g., a class name.
    Assuming camelCase Polar and InitialUpperCamelcase Python
    naming conventions, just downcase the initial letter."""
    assert isinstance(name, str), f"{name} is not a string"
    return name[0].lower() + name[1:]

def python_name(name):
    """Python name from Polar name.
    Assuming camelCase Polar and InitialUpperCamelcase Python
    naming conventions, just upcase the initial letter."""
    assert isinstance(name, str), f"{name} is not a string"
    return name[0].upper() + name[1:]

class NamedFact(Fact):
    """className(arg1, arg2, ...)"""

    def __new__(cls, *args):
        # Convert the dataclass into a tuple.
        # It may be better to teach tell about dataclasses.
        fact = Fact((polar_name(cls.__name__), *args))
        try:
            # Set the dataclass fields.
            for (arg, field) in zip(args, fields(cls)):
                setattr(fact, field.name, arg)
        except TypeError:
            # Ignore non-dataclass classes.
            pass
        return fact

def module_from_facts(kb, name, doc=None):
    # Create the file named `name` in the same directory
    # as this file
    with open(Path(__file__).parent / name, "w") as module:
        module.write("# AUTOMATICALLY GENERATED FILE. DO NOT EDIT.\n")
        module.write("'''Python interface classes for Polar "
                     f"'{Path(name).stem}' module.'''\n\n")
        module.write("from .pymod import NamedFact\n")
        module.write("from dataclasses import dataclass\n")
        module.write("from typing import Tuple, Union\n\n")
        module.write("Expr = Union[str, Tuple]\n")

        def make_argname(expr):
            if isinstance(expr, (tuple, list)) and expr:
                return make_argname(expr[0])
            elif kb.is_var(expr):
                return str(expr)[1:] # elide "?"
            else:
                return str(expr)

        classes = {}
        def make_class(fact):
            assert isinstance(fact, tuple), \
                f"{fact} must be a tuple, not a {type(fact)}"
            if (not fact or
                not fact[0] or
                kb.is_var(fact[0][0])):
                return

            # Start building a string representation of the fact.
            (name, *args) = fact[0]
            pyname = python_name(name)
            cls = f"""
@dataclass
class {pyname}(NamedFact):
    '''{fact[0]!s}'''
"""

            # Add the args as fields. There are two things to watch out for:
            # fields that may have the same name, and types that may not be
            # defined yet.
            argnames: dict[str, int] = {}
            for arg in args:
                argname = make_argname(arg)
                pyargname = python_name(argname) # before suffix, if any
                if argname in argnames:
                    # If there's a name collision, append a counter.
                    argnames[argname] += 1
                    argname += str(argnames[argname])
                else:
                    argnames[argname] = 0
                if isinstance(arg, tuple):
                    # Yield dependent classes first.
                    if isinstance(arg, tuple):
                        yield from make_class((Fact(arg),))
                    cls += f"    {argname}: {pyargname}\n"
                else:
                    cls += f"    {argname}: Expr\n"

            # If we haven't already and it isn't a special operator,
            # yield this fact's string representation.
            if name not in classes and not kb.is_special_operator(name):
                classes[name] = cls
                yield cls

            # And then yield the fact's body's clauses' representations.
            for x in fact[1:]:
                if x:
                    yield from make_class((Fact(x),))

        # Write out string representations of all of the facts.
        for fact in kb.facts:
            for cls in make_class(fact):
                module.write(cls)
