from dataclasses import dataclass
from typing import Tuple

from polar.classes import Specializer
from polar.exceptions import PolarRuntimeException

class GroupError(PolarRuntimeException): pass

@dataclass(frozen=True)
class Group(Specializer):
    """A group is a disjunctive specializer, aka a union type.
    It has a name and a tuple of members, each of which must
    be another specializer (e.g., a class or another group)."""
    name: str
    members: Tuple[Specializer, ...] = ()

    def is_applicable(self, arg, **kwargs):
        """A group is applicable to an argument if any of its members are."""
        return any(member.is_applicable(arg) for member in self.members)

    def is_subspecializer(self, other, arg, **kwargs):
        """A group is less specific than any specifier it contains,
        directly or indirectly."""
        def contains(other):
            return (other in self.members or
                    any(other.is_subspecializer(member, arg) for member in self.members))
        return not contains(other)

    def make_instance(self, **kwargs):
        raise GroupError(f"can only instantiate a class, not a group: {self.name}")
