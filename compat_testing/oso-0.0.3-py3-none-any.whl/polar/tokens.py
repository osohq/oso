"""Proof tokens."""

from .facts import map_tree
from .merkle.merkle import to_bytes, to_string
from .merkle.merklefacts import MerkleFacts

from base64 import b64encode, b64decode
import json

def serialize_json64(x):
    """Serialize a Python object as base64-encoded JSON.

    >>> serialize_json64('')
    'IiI='
    >>> serialize_json64({'foo': ['bar', 1], 'bar': None})
    'eyJmb28iOiBbImJhciIsIDFdLCAiYmFyIjogbnVsbH0='
    """
    return b64encode(json.dumps(x).encode("utf-8")).decode("ascii")

def deserialize_json64(x):
    """Deserialize base64-encoded JSON to a Python object.

    >>> deserialize_json64('IiI=')
    ''
    >>> deserialize_json64('eyJmb28iOiBbImJhciIsIDFdLCAiYmFyIjogbnVsbH0=')
    {'foo': ['bar', 1], 'bar': None}
    """
    return json.loads(b64decode(x))

def serialize(query, proof):
    assert ";" not in query, f"bad query {query}"
    def ser(x):
        if isinstance(x, (str, bytes)):
            return to_string(x)
        elif isinstance(x, (list, tuple)) and len(x) == 2:
            return f"{to_string(x[0])}:{serialize_json64(x[1])}"
        else:
            assert False, f"don't know how to serialize {x}"
    return f"{serialize_json64(query)};" + ",".join(map(ser, proof))

def deserialize(token):
    (query, proof) = token.split(";")
    query = deserialize_json64(query)
    def de(x):
        if ":" in x:
            (sig, caveat) = x.split(":")
            return (to_bytes(sig), deserialize_json64(caveat))
        else:
            return to_bytes(x)
    proof = tuple(map(de, proof.split(",")))
    return (query, proof)

class TokenFacts(MerkleFacts):
    """A Merkle-tree backed knowledge base that can generate proof tokens.

    >>> from polar.parser import Variable, load, parse
    >>> from polar.merkle.merkle import Hex
    >>> kb = TokenFacts(mac=lambda k, x: Hex(k, x)[:6])
    >>> load("tests/test_policies/users.pol", kb) is kb
    True
    >>> token = kb.get_token(parse('allow(user("alex"), get("http://localhost:3001/"))'))
    >>> token and kb.verify_token(token)
    True
    """

    def get_token(self, query, *args, **kwargs):
        """Return a serialized query proof."""
        # TODO: fix below example to not use atoms, then return it to the docstring
        # >>> kb = TokenFacts(mac=lambda k, x: to_bytes(x))
        # >>> kb.root.sig
        # b''
        # >>> kb.tell(('x',))
        # >>> kb.tell(('y',))
        # >>> kb.tell(('z', 'x', 'y'))
        # >>> kb.root.sig
        # b'xyzxy'
        # >>> next(kb.proof((('z',))))
        # (b'xyzxy', b'zxy', b'x', b'y')
        # >>> kb.get_token((('z',)))
        # 'WyJ6Il0=;xyzxy,zxy,x,y'
        # >>> deserialize(kb.get_token((('z',))))
        # (['z'], (b'xyzxy', b'zxy', b'x', b'y'))
        for proof in self.proof(query, *args, **kwargs):
            if proof:
                return serialize(query, proof)

    def verify_token(self, token, *args, **kwargs):
        """Verify a serialized query proof."""
        try:
            (query, proof) = deserialize(token)
            return self.verify(proof, query, *args, **kwargs)
        except:
            return False

if __name__ == "__main__":
    from doctest import testmod
    (failures, tests) = testmod(verbose=True)
    if failures > 0:
        exit(failures)
