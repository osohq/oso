"""Prolog-style knowledge base.

The two fundamental operations on a KB are: _tell_ the KB a new fact
or rule, and _query_ it for a matching fact. This module implements
those two operations.

Concretely, the knowledge base (KB) stores Horn clauses. A Horn clause
represents either:

* a rule with a head and a body,
* a fact, which has just a head.

Clauses are represented as `tuple` subclasses, so the head is `clause[0]`
and the body is `clause[1:]`. Only Horn clauses should be stored in the KB,
so any atoms (non-tuple data) must be wrapped as a one-tuple: `(atom,)`.

The same representation is used for _predicates_, which are facts that
can have arguments: `even(2)`. The head of a predicate is its name, and
its body is its arguments. Predicates thus share an underlying representation
(tuples) with facts and rules.

One important kind of atom is the _variable_, which can be _bound_ to
any other term (atomic or otherwise). Bindings are stored in _environment_
structures, each of which maintains a frame (a dictionary) of variable/value
bindings.

_Unification_ is the basic matching operator used in querying the KB. It is
essentially an equality operator, but if either side is an unbound variable,
then it is bound to the other side, and the match succeeds with the new
environment.

Facts and rules in the KB are queried via the resolution algorithm:
starting with a query fact, try to match it (using unification) against
the head of each fact in the KB; if the matched fact was the head of a rule,
then recursively query for the body clauses, too. If the process terminates
with a match, then the query is successful, and an environment with the
unifying bindings is returned.

A successful query has a _proof_, which is the list of KB nodes (sources)
that were unified to produce the successful result.
"""
import copy
import os
import sys
from collections import deque
from dataclasses import asdict, dataclass, is_dataclass, FrozenInstanceError
from itertools import chain
import inspect
from types import BuiltinMethodType, MethodType, GeneratorType
from typing import (Any, Callable, Dict, Iterator, List, Union, Tuple as TupleType, Optional, cast,
                    TYPE_CHECKING)

from typing_extensions import Literal

from polar.classes import Class, Instance, class_of, find_class, GenericPredicate, Instance, Method, NoApplicableMethods, Specializer
from polar.groups import Group
from polar.exceptions import PolarRuntimeException, UnboundVariable
from polar.debug import DebugContext
from polar.polar_types import is_tuple, is_dict, map_tree

if TYPE_CHECKING:
    from polar.parser import CodeContext

if sys.platform.lower() == "win32":
    os.system("color")

class Atom(object):
    """An atomic fact."""

    def __repr__(self):
        # Workaround for infinite loop on Python >= 3.8.2
        # Relevant: https://bugs.python.org/issue36793
        if isinstance(self, int):
            return str(int(self))
        return str(self)

class Fact(tuple):
    """A compound fact(arg1, arg2, ...)."""

    def __str__(self):
        pred = str(self[0])
        if len(self) == 1:
            return f"({pred},)"
        else:
            args = ", ".join(tuple(str(x) for x in self[1:]))
            return f"{pred}({args})"

def copy_fact(fact, new_contents):
    """Copy a fact's Python type and attributes (especially "sig"),
    but with new contents."""
    copy = type(fact)(new_contents)
    if hasattr(fact, "__dict__"):
        for k, v in fact.__dict__.items():
            try:
                setattr(copy, k, v)
            except (ValueError, FrozenInstanceError):
                pass
    if hasattr(fact, "code_context"):
        copy.code_context = fact.code_context
    return copy

@dataclass
class Variable:
    """Variables are bound to values in environments."""
    name: str = ""

    def __eq__(self, other):
        return (self.name == other.name
                if isinstance(other, type(self))
                else self.name == str(other))

    def __hash__(self):
        return hash(self.name)

    def __str__(self):
        return self.name

    __repr__ = __str__

GENVAR_COUNTER: int = 1000
def genvar(var="g", counter=None):
    """Generate a fresh variable."""
    if counter is None:
        global GENVAR_COUNTER
        counter = GENVAR_COUNTER
        GENVAR_COUNTER += 1
    return Variable(f"_{var}_{counter}")

class Environment:
    """An environment represents a frame of variable bindings.
    Environments may be chained through a parent pointer, and
    variable lookups are recursive. Thus, bindings in a child
    frame may shadow those of a parent.

    >>> e = Environment()
    >>> e['x'] = 'y'
    >>> e['x']
    'y'
    >>> e['y']
    Traceback (most recent call last):
    ...
    polar.exceptions.UnboundVariable: Variable y is unbound.
    >>> f = Environment(e)
    >>> f.parent is e
    True
    >>> f['x']
    'y'
    >>> f['x'] = 'z'
    >>> f['x']
    'z'
    >>> e['x']
    'y'
    >>> f['y'] = 'y'
    >>> f.vars() == ('x', 'y')
    True
    >>> 'y' in f
    True
    >>> 'y' in e
    False
    >>> e.subst(('f', Variable('x')))
    ('f', 'y')
    """

    def __init__(self,
                 parent: 'Environment' = None,
                 source=None,
                 rule_stack: Optional[deque] = None,
                 debug_context: Optional[DebugContext] = None):
        self.frame: Dict[str, Variable] = {}
        self.parent = parent
        self.source = source
        self.rule_stack = rule_stack or deque()
        self.debug_context = debug_context or DebugContext()

    def add_caveat(self, caveat):
        if isinstance(self.source, list):
            self.source.append(caveat)
        else:
            self.source = [self.source, caveat]

    def is_var(self, x):
        return isinstance(x, Variable)

    def is_unbound_var(self, x):
        return self.is_var(x) and x not in self

    def __contains__(self, x):
        """Return true if x is a bound variable."""
        try:
            self[x]
            return True
        except UnboundVariable:
            pass
        return False

    def __getitem__(self, var):
        """Return the value of a variable, or raise UnboundVariable."""
        try:
            return self.frame[var]
        except KeyError as e:
            pass
        if self.parent:
            return self.parent[var]
        else:
            raise UnboundVariable(var)

    def __setitem__(self, var, value):
        """Bind a variable to a value."""
        if not self.is_var(var):
            var = Variable(var)
        self.frame[var] = value

    def copy_vars(self, term):
        """Copy a term with fresh free variables."""
        rename = make_env()
        def copy_var(x):
            if rename.is_var(x):
                if x not in rename:
                    rename[x] = genvar(x)
                return rename[x]
            else:
                return x
        return map_tree(copy_var, term)

    def check_singletons(self, term):
        """Warn about free variables that occur only once in term."""
        env = make_env()
        singletons = {}
        def check_singleton(x):
            if env.is_var(x):
                if x in singletons:
                    singletons[x] = False
                else:
                    singletons[x] = True
        map_tree(check_singleton, term)

        singletons = [var
                      for var, singleton in singletons.items()
                      if singleton and not var.name.startswith("_")]
        if singletons:
            lines = [var.code_context.lineno for var in singletons]
            on_line = ""
            if lines:
                lines = list(sorted(set(lines)))
                if len(lines) == 1:
                    on_line = f" on line {lines[0]}"
                else:
                    on_line = f" on lines {lines}"
            print(f"Warning: singleton variables {singletons}" + on_line)

    def subst(self, term, check=False):
        """Substitute values from our bindings for term's free variables.
        If check is true, ensure that _all_ such variables are bound."""
        def subst(x):
            if self.is_var(x):
                if x in self:
                    return map_tree(subst, self[x])
                elif check:
                    raise UnboundVariable(x)
            return x
        return map_tree(subst, term)

    def vars(self, include_temporary=False):
        """Return a tuple of bound variables."""
        return (tuple(var
                      for var in self.frame.keys()
                      if not var.name.startswith("_") or include_temporary) +
                self.parent.vars(include_temporary) if self.parent else ())

    def to_dict(self):
        vars = self.vars()
        return {k: self[k] for k in vars}

    def trace(self, trace=(), transform=None):
        """Return a tuple of sources up the parent chain.
        Traces do not yet include binding frames, but possibly should.
        An optional transformation may be supplied as a function of
        one argument (the source)."""
        trace = (self.parent.trace((self.source, *trace)) # note: no transform
                 if self.parent and not isinstance(self.parent, EmptyEnvironment)
                 else (self.source, *trace))
        if transform:
            # Perform the transform only at the top-most level.
            trace = tuple(map(transform, filter(None, trace)))
        return trace

    def debug_point(self, point_name, query):
        self.debug_context.debug_point(point_name, query, self)

    def start_debugging(self):
        self.debug_context.enable()

class EmptyEnvironment(Environment):
    """An environment that is devoid of bindings.
    A reasonable root for a tree of environments.

    >>> e = EmptyEnvironment()
    >>> e['x']
    Traceback (most recent call last):
    ...
    polar.exceptions.UnboundVariable: Variable x is unbound.
    >>> e['x'] = 'y'
    Traceback (most recent call last):
    ...
    polar.exceptions.UnboundVariable: Variable x is unbound.
    """

    def __getitem__(self, var):
        raise UnboundVariable(var)

    def __setitem__(self, var, value):
        raise UnboundVariable(var)

def make_env(parent: Environment = None, source=None) -> Environment:
    """Make a non-trivial environment."""
    if parent is None:
        parent = EmptyEnvironment()
        rule_stack: Optional[deque] = deque()
        debug_context = DebugContext()
    else:
        source = source or parent.source
        rule_stack = copy.copy(parent.rule_stack)
        debug_context = parent.debug_context

    return Environment(parent,
                       source=source,
                       rule_stack=rule_stack,
                       debug_context=debug_context)

Match = Union[Environment, Literal[False]]
Matches = Iterator[Environment]

def unify(x, y, env: Environment = None, verbose=False, source=None) -> Match:
    """Unify the trees x and y in some environment.
    Return the environment updated with unifying bindings,
    or False if the unification fails.

    >>> unify(True, False)
    False
    >>> unify(True, True) is not False
    True
    >>> unify((0, (1, 2)), (0, (1, 2))) is not False
    True
    >>> unify(Variable('x'), (0, (1, 2)))['x']
    (0, (1, 2))
    >>> unify((0, Variable('y')), (0, (1, 2)))['y']
    (1, 2)
    >>> unify((0, (1, Variable('z'))), (0, (1, 2)))['z']
    2
    >>> unify((0, (1, 2)), (0, (1, Variable('z'))))['z']
    2
    """

    # We use a pair of mutally recursive helper functions to unify.
    # This code is based on Peter Norvig's in PAIP, page 372.
    def unify(x, y, env: Environment) -> Match:
        """Return an environment if x and y match, or False otherwise."""
        match: Match = env
        if x is None or y is None:
            return False
        elif env.is_var(x):
            return unify_var(x, y, env)
        elif env.is_var(y):
            return unify_var(y, x, env)
        elif is_tuple(x) and is_tuple(y):
            # All elements must match.
            if len(x) != len(y):
                return False
            for (x, y) in zip(x, y):
                match = unify(x, y, env)
                if not match:
                    return False
            return match
        elif is_dict(x) and is_dict(y):
            # All the fields must match.
            if x.keys() != y.keys():
                return False

            # And the values must match.
            for k in x.keys():
                match = unify(x[k], y[k], cast(Environment, match))
                if not match:
                    return False
            return match
        elif type(x) == Instance and type(y) == Instance:
            return (class_of(x) == class_of(y) and unify(x.fields, y.fields, env))
        elif isinstance(x, Instance) and isinstance(y, Instance):
            raise PolarRuntimeException(f"Invalid operation: cannot unify instances {type(x)} and {type(y)}.")
        elif x == y:
            return env
        else:
            return False

    def unify_var(v, x, env: Environment) -> Match:
        """Unify a variable v with the value x, using and maybe extending env.
        Recursively unifies values that are themselves variables."""
        if v is None or x is None:
            return False
        if v in env:
            return unify(env[v], x, env)
        elif env.is_var(x) and x in env:
            return unify(v, env[x], env)
        else:
            env[v] = x
            return env

    match = unify(x, y, make_env(parent=env, source=source))
    if verbose:
        sub_x, sub_y = x, y
        if env:
            sub_x = env.subst(x)
            sub_y = env.subst(y)
        if isinstance(match, Environment):
            print(f"Unify: {sub_x} = {sub_y} -> {match.frame if match else 'false'}")
    return match

def isa(x, y, env: Environment, **kwargs) -> Match:
    """If x ≤ y in the partial order over types, return
    the environment updated with any unifying bindings.
    Otherwise return False."""
    if isinstance(x, Instance) and isinstance(y, Instance):
        # Compare the classes of x and y, then their fields.
        if class_of(x).is_subclass(class_of(y)):
            instance_match: Match = env
            for key, y_val in y.fields.items():
            # only unify on the RHS fields
                try:
                    # generator object returned from `get_field()`
                    x_val = next(x.get_field(key))
                except (PolarRuntimeException, StopIteration):
                    return False
                instance_match = isa(x_val, y_val, cast(Environment, instance_match), **kwargs)
                if not instance_match:
                    return False
            return instance_match
        else:
            return False
    elif isinstance(x, Instance) and is_dict(y):
        # Compare just the fields.
        return isa(x.fields, y, env, **kwargs)
    elif is_dict(x) and isinstance(y, Instance):
        # No dictionary is more specific than an instance.
        return False
    elif is_dict(x) and is_dict(y):
        dict_match: Match = env
        # Every field in y must have a compatible value in x.
        for k, v in y.items():
            if k not in x:
                return False
            dict_match = isa(x[k], y[k], cast(Environment, dict_match), **kwargs)
            if not dict_match:
                return False
        return dict_match
    else:
        # Punt to unification for unclassed objects.
        # The order (y, x) is to ensure that unbound temporaries
        # are correctly bound to unbound variables in rule heads;
        # see UnificationSpecializer.is_applicable.
        return unify(y, x, env, **kwargs)

SpecialOperator = Callable[[TupleType, Environment, 'Facts'], Matches]
ExternalLookup = Callable[[TupleType], Iterator[TupleType]]

class SpecialOperators(dict):
    """A dictionary whose keys name special operators for
    the knowledge base query engine, and whose values are
    functions of three arguments: a list of arguments to
    the special operator, an environment, and a KB."""

    def is_special_operator(self, op) -> bool:
        if is_tuple(op):
            op = op[0] # take the head
        try:
            return op in self
        except TypeError: # e.g., could be unhashable
            return False

    def special_operator(self, expr, env: Environment, facts: 'Facts') -> Matches:
        """Call the special operator at the head of expr
        with an argument list, environment, and KB."""
        f: SpecialOperator = self[expr[0]]
        return f(expr[1:], env, facts)

# Python functions implementing special operators like `=` and `|`
# (i.e., operators not supported by the core resolution algorithm)
# are recorded in this global dictionary, indexed by operator.
# Many of these are infix operators, which require special support
# in the parser right now.
SPECIAL_OPERATORS: SpecialOperators = SpecialOperators({})

def special_operator(op: str):
    """A function decorator for special operators.
    Takes one argument, the name of the operator,
    and decorates a special operator function, which
    takes a list of arguments, an environment, and a KB."""
    def special_operator(f: SpecialOperator) -> SpecialOperator:
        """Record the special operator in the global dictionary."""
        SPECIAL_OPERATORS[op] = f
        return f
    return special_operator

@special_operator("<")
def lt(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) < env.subst(y):
        yield env

@special_operator("<=")
def leq(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) <= env.subst(y):
        yield env

@special_operator(">")
def gt(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) > env.subst(y):
        yield env

@special_operator(">=")
def geq(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) >= env.subst(y):
        yield env

@special_operator("==")
def eq(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) == env.subst(y):
        yield env

@special_operator("!=")
def neq(args, env: Environment, facts: 'Facts') -> Matches:
    (x, y) = args
    if env.subst(x) != env.subst(y):
        yield env

@special_operator("=")
def equal(args, env: Environment, facts: 'Facts', **kwargs) -> Matches:
    """Equality as unification."""
    (x, y) = args
    match = unify(x, y, env, **kwargs)
    if isinstance(match, Environment):
        yield match

@special_operator("isa")
def isa_op(args, env: Environment, facts: 'Facts', **kwargs):
    """isa special operator."""
    (x, y) = env.subst(args)
    match = isa(x, y, env, **kwargs)
    if isinstance(match, Environment):
        yield match

@special_operator("|")
def disjunction(args, env: Environment, facts: 'Facts') -> Matches:
    """This or that. Equivalent to two rules. Yields all possible
    solutions if either the left, or right, or both succeed."""
    (x, y) = args
    yield from chain(facts.query((x,), env, preprocess=False),
                     facts.query((y,), env, preprocess=False))

@special_operator("!")
def negate(args, env: Environment, facts: 'Facts') -> Matches:
    """Negation as failure: if a query for the sole argument succeeds,
    we fail. If it fails, we return the original environment."""
    match = next(facts.query(args[0], env, preprocess=False), False)
    if not match:
        yield env

@special_operator("cut")
def cut(args: TupleType, env: Environment, facts: 'Facts'):
    predicate = facts.rules[env.rule_stack[0][0]]
    assert isinstance(predicate, GenericPredicate)
    # WOW, CUT HACK! See GenericPredicate.__call__
    setattr(predicate, "cut", True)
    yield env

@special_operator(".")
def attr(args, env: Environment, facts: 'Facts'):
    """Attribute lookup, 3-arg version: `.(dict, key, result)`.
    This special operator is not usually written directly;
    the ./2 operator is translated below into calls to it."""
    (d, key, result) = args
    while env.is_var(d):
        d = env[d]

    if is_dict(d) and env.is_var(key):
        for k in d.keys():
            e = unify(k, key, env)
            if isinstance(e, Environment):
                try:
                    match = unify(d[k], result, e)
                except KeyError:
                    raise PolarRuntimeException(f"{d!r} does not have field {k!r}.")

                if isinstance(match, Environment):
                    yield match
    else:
        if is_tuple(key):
            # Method arguments are present, e.g., `a.b(c)`.
            (key, *lookup_args) = key
        else:
            # An ordinary attribute lookup, e.g., `a.b`.
            lookup_args = ()

        if is_dict(d):
            # A dictionary lookup.
            if key not in d:
                raise PolarRuntimeException(f"{d} does not have field {key}")
            match = unify(d[key], result, env)
            if match:
                yield match
            return

        # Chaining None values
        if d is None:
            if env.is_unbound_var(result):
                # None value must be bound to unbound vars for chaining lookups
                match = make_env(env)
                match[result] = None
                yield match
            return

        # `d` should only be an Instance at this point
        assert isinstance(d, Instance), f"Cannot lookup attribute on type {type(d)}"

        values = d.get_field(key, env.subst(lookup_args), env=env)
        for value in values:
            if value is None:
                if env.is_unbound_var(result):
                    # None value must be bound to unbound vars for chaining lookups
                    match = make_env(env)
                    match[result] = None
                    yield match
                return
            match = unify(value, result, env)
            if match:
                yield match

@special_operator("debug")
def debug(args: TupleType, env: Environment, facts: 'Facts'):
    """Enter the debugger.

    Example::

        debugMe(x, y) := debug(x, y), x = y;
    """
    env.start_debugging()
    env.debug_point("break", args)

    yield env

SPYPOINTS: Dict[str, bool] = {}

@special_operator("spy")
def spy(args: TupleType, env: Environment, facts: 'Facts'):
    """Set a spy-point on the given predicate.
    Whenever that predicate is encountered during a query,
    the context, arguments, and result will be printed."""
    (predicate,) = (args)
    SPYPOINTS[predicate] = True
    yield env

@special_operator("unspy")
def unspy(args: TupleType, env: Environment, facts: 'Facts'):
    """Unset a spy-point on the given predicate."""
    (predicate,) = (args)
    try:
        del SPYPOINTS[predicate]
    except KeyError:
        pass
    yield env

REWRITES: List[Callable] = []
def rewrite(function):
    """A function decorator for term rewriters.
    Adds it to the default REWRITES list."""
    if function not in REWRITES:
        REWRITES.append(function)

    return function

@rewrite
def rewrite_lookups(fact, kb):
    """Rewrite attribute lookups `a.b` as references to temporary variables.
    Such lookups are translated by the parser into calls to the `./2` special
    operator, e.g., `a.b` → `.(a, b)`. Our job here is to get a value from
    such a lookup, so we rewrite calls into the `./3` special operator:
    `.(a, b)` → `.(a, b, x), x` where `x` is a unique temporary."""

    def rewrite(term, lookups: List) -> TupleType[Any, List]:
        """Rewrite attribute lookups in term, accumulating lookups."""
        if is_tuple(term) and len(term) == 3 and term[0] == ".":
            # We have a `./2` term, e.g., `.(dictionary, key)`.
            (dictionary, key) = term[1:]
            (dictionary, lookups) = rewrite(dictionary, lookups)
            (key, lookups) = rewrite(key, lookups)

            # Make a new variable to hold the looked-up value.
            value = genvar("value")

            # Form the `./3` lookup term by appending `value`.
            lookup = copy_fact(term, (term[0], dictionary, key, value))
            lookups.append(lookup)

            # And rewrite the term to just `value`.
            return (value, lookups)
        elif is_tuple(term):
            # A predicate, conjunction, etc. Recursively rewrite subterms.
            new_term = []
            for subterm in term:
                (new_subterm, lookups) = rewrite(subterm, lookups)
                new_term.append(new_subterm)
            return (copy_fact(term, tuple(new_term)), lookups)
        elif is_dict(term):
            # A dictionary. Recursively rewrite keys & values.
            new_dict = {}
            for (key, value) in term.items():
                (new_key, lookups) = rewrite(key, lookups)
                (new_value, lookups) = rewrite(value, lookups)
                new_dict[new_key] = new_value
            return (copy_fact(term, new_dict), lookups)
        else:
            # Anything else: leave it alone.
            return (term, lookups)

    if is_tuple(fact):
        if len(fact) == 1:
            # A fact. If we need any lookups, we will turn it into a rule,
            # with the lookups as the new RHS.
            (fact, lookups) = rewrite(fact, [])
            if lookups:
                fact = copy_fact(fact, tuple(fact) + tuple(lookups))
        else:
            # A rule. Rewrite ./2 in the head to temporary variables
            # that are bound at the beginning of the body, and rewrite
            # the other body clauses one at a time, inserting lookups
            # between them.
            (lhs, *rhs) = fact
            (lhs, new_rhs) = rewrite(lhs, [])
            for x in rhs:
                (y, lookups) = rewrite(x, [])
                new_rhs.extend(lookups)
                new_rhs.append(y)
            fact = copy_fact(fact, (lhs, *new_rhs))
    return fact

@rewrite
def rewrite_instances(fact, kb):
    """Rewrite instance expressions (tagged dictionaries) as instances."""
    def rewrite(term):
        if is_tuple(term):
            # A predicate, conjunction, etc. Recursively rewrite subterms.
            return copy_fact(term, tuple(rewrite(subterm) for subterm in term))
        elif is_dict(term) and hasattr(term, "tag"):
            cls = find_class(term.tag)
            new_dict = copy_fact(term, {rewrite(k): rewrite(v) for k, v in term.items()})
            old_context = getattr(term, "code_context", None)
            new_instance = cls.make_instance(**new_dict)
            new_instance.code_context = old_context
            return new_instance
        elif is_dict(term):
            return copy_fact(term, {rewrite(k): rewrite(v) for k, v in term.items()})
        else:
            # Anything else: leave it alone.
            return term
    return rewrite(fact)

# This global dictionary stores Python functions that can be used
# as external hooks in a Polar program. E.g., `external(foo)`
# looks for a `foo` entry here, and calls it with an environment
# and a spread list of arguments; it should yield matches containing
# whatever bindings are appropriate.
EXTERNALS: SpecialOperators = SpecialOperators({})

def external(name: str):
    """A function decorator for external operators."""
    def external(function: SpecialOperator) -> SpecialOperator:
        EXTERNALS[name] = function
        return function
    return external

def external_lookup(name: str):
    """A function decorator for external operators."""
    def external_lookup(function: ExternalLookup) -> ExternalLookup:
        def lookup(env: Environment, *args):
            result_var = args[-1]
            args = args[:-1]
            has_unbound_args = any((env.is_unbound_var(arg) for arg in args))
            if has_unbound_args:
                raise PolarRuntimeException("too many unbound args.")

            args = tuple((env.subst(arg) for arg in args))

            if not env.is_unbound_var(result_var):
                raise PolarRuntimeException("no unbound args")

            for result in function(*args):
                env = make_env(env)
                env[result_var] = result
                yield env

        EXTERNALS[name] = lookup
        # return the original function so it still works locally
        # as normal
        return function
    return external_lookup

@special_operator("external")
def query_external(args: TupleType, env: Environment, facts: 'Facts') -> Matches:
    if len(args) != 1:
        raise PolarRuntimeException(f"got {len(args)} args, not 1 for query external")

    pred = args[0][0]
    # @TODO: Currently the only external is httpResourceMap, which
    # actually would prefer to use the external types as polar Instances
    # since this is going to become internal to polar.. I think?
    # args = tuple(instantiate_externals(env.subst(arg)) for arg in args[0][1:])
    args = tuple(env.subst(arg) for arg in args[0][1:])
    try:
        ext = EXTERNALS[pred]
    except KeyError:
        return
    yield from ext(env, *args)


@special_operator("caveat")
def add_caveat(args: TupleType, env: Environment, facts: 'Facts') -> Matches:
    """Success dependent on external data. If querying for args succeeds,
    add the unifier as a caveat to the matching environment."""
    match = next(facts.query(args, env, preprocess=False), False)
    if isinstance(match, Environment):
        unifier = match.subst(args)
        match.add_caveat(unifier)
        yield match

# Extra-special operators (external-data-dependent predicates).
# Caveats should have a dummy definition that is always true (FIXME),
# which will be used during a normal query or proof. During verification,
# though, the caveat will be evaluated as an external hook.
CAVEATS: SpecialOperators = SpecialOperators({})
def caveat(name):
    def caveat(function):
        CAVEATS[name] = function
        return function
    return caveat

def try_caveat(env: Environment, caveat) -> Matches:
    """Look up a caveat by name, and call it."""
    try:
        cav = CAVEATS[caveat[0]]
        yield from cav(env, *caveat[1:])
    except KeyError:
        pass

def caveats(env: Environment, trace) -> bool:
    """Given a query trace, verify all of the caveats therein."""
    assert is_tuple(trace)

    for x in trace:
        if is_tuple(x):
            (sig, caveats) = x
            for caveat in caveats:
                if not try_caveat(env, caveat):
                    return False
    return True


class Facts:
    """A knowledge base (KB) of facts and rules (Horn clauses).
    Clauses are represented as tuples: the first element is
    the head, and the rest comprise the tail. Variables are
    represented by instances of a class that may be supplied
    to the initializer.

    >>> kb = Facts()
    >>> kb.facts
    []
    >>> next(kb.query((('=', '1', '1'),))) is not False
    True
    >>> next(kb.query((('=', '1', '2'),)), False)
    False
    >>> next(kb.query((('!', (('=', '1', '2'),),),))) is not False
    True

    Examples from <http://web.cse.ohio-state.edu/~stiff.4/cse3521/prolog-resolution.html>
    >>> kb.tell((('f', 'a'),))
    >>> kb.tell((('f', 'b'),))
    >>> kb.tell((('g', 'a'),))
    >>> kb.tell((('g', 'b'),))
    >>> kb.tell((('h', 'b'),))
    >>> x = Variable('x')
    >>> kb.tell((('k', x), ('f', x), ('g', x), ('h', x)))
    >>> len(kb.facts)
    6
    >>> next(kb.query(kb.facts[0])) is not False
    True
    >>> tuple(env['x'] for env in kb.query((('f', Variable('x')),)))
    ('a', 'b')
    >>> tuple(env['x'] for env in kb.query((('g', Variable('x')),)))
    ('a', 'b')
    >>> tuple(env['x'] for env in kb.query((('h', Variable('x')),)))
    ('b',)
    >>> tuple(env['y'] for env in kb.query((('k', Variable('y')),)))
    ('b',)
    >>> next(kb.query((('!', (('k', 'b'),),),)), False)
    False
    >>> next(kb.query((('!', (('k', 'a'),),),))).vars()
    ()

    >>> next(kb.query((('=', ('a',), ('a',)),))).vars()
    ()
    >>> next(kb.query((('=', ('a',), ('b',)),)), False)
    False

    >>> next(kb.query((('|', ('f', 'a'), ('f', 'b')),)), False) is not False
    True
    >>> next(kb.query((('|', ('f', 'c'), ('f', 'b')),)), False) is not False
    True
    >>> tuple(env['x'] for env in kb.query((('|', ('f', 'c'), ('f', Variable('x'))),)))
    ('a', 'b')

    >>> next(kb.query((('g', 'b'),))) is not False
    True
    >>> kb.tell((('loves', ('vincent', 'mia')),))
    >>> kb.tell((('loves', ('marcellus', 'mia')),))
    >>> (a, b, c) = (Variable('a'), Variable('b'), Variable('c'))
    >>> kb.tell((('jealous', (a, b)), ('loves', (a, c)), ('loves', (b, c))))
    >>> (x, y) = (Variable('x'), Variable('y'))
    >>> tuple((env[x], env[y]) \
              for env in kb.query((('jealous', (x, y)),))) \
    #doctest: +NORMALIZE_WHITESPACE
    (('vincent', 'vincent'),
     ('vincent', 'marcellus'),
     ('marcellus', 'vincent'),
     ('marcellus', 'marcellus'))
    """

    def __init__(self,
                 facts: List[tuple] = None,
                 rules: Dict[str, GenericPredicate] = None,
                 source=None,
                 rewrites=REWRITES,
                 specops: SpecialOperators = SPECIAL_OPERATORS):
        self.facts = facts or []
        self.rules = rules or {}
        self.source = source
        self.rewrites = rewrites
        self.specops = specops

    def is_var(self, x):
        return isinstance(x, Variable)

    def tell(self, fact: tuple, check_singletons=True):
        """Add a fact to the knowledge base."""
        fact = self.preprocess(fact)
        if fact:
            if check_singletons:
                make_env().check_singletons(fact)

            if is_tuple(fact) and is_tuple(fact[0]) and isinstance(fact[0][0], str):
                # A predicate. Ensure it's generic, and make a method for it.
                # The created method is automatically registered with its GP.
                (name, *args) = fact[0]
                generic_predicate = self.find_or_make_generic_predicate(name)
                specs = tuple(UnificationSpecializer(arg) for arg in args)
                code_context = getattr(fact, 'code_context', None)
                method = PolarMethod(generic_predicate, params=args, body=fact[1:], specs=specs,
                                     source=fact, code_context=code_context)
            self.facts.append(fact)

    def find_or_make_generic_predicate(self, name):
        """A generic predicate contains implementations of rules for all predicates
        with the same name."""
        if name not in self.rules:
            generic_predicate = GenericPredicate(name)
            self.rules[name] = generic_predicate
        return self.rules[name]

    def preprocess(self, fact):
        """Prepare a term for addition to the knowledge base.
        This may involve some amount of term rewriting."""
        for rewrite in self.rewrites:
            fact = rewrite(fact, self)
        return fact

    def is_special_operator(self, op) -> bool:
        if self.specops:
            return self.specops.is_special_operator(op)
        else:
            return False

    def special_operator(self, expr, env: Environment, facts) -> Matches:
        if self.specops:
            for match in self.specops.special_operator(expr, env, facts):
                if isinstance(match, Environment):
                    match.source = match.subst((expr,))
                    yield match

    def query(self, query: tuple,
              env: Environment = None,
              preprocess=True,
              source=None,
              verbose=False) -> Matches:
        """Query the knowledge base via resolution.
        Yields environments with unifying bindings."""
        if source is None:
            source = self
        if env is None:
            env = make_env(source=source)
        if preprocess:
            query = self.preprocess(query)
        if verbose:
            print(f"Query: {query}")

        if is_tuple(query) and self.is_special_operator(query[0]):
            # Handle special operators.

            env.debug_point("call", query)

            for match in self.special_operator(query[0], env, self):
                yield from self.query(query[1:],
                                    env=match,
                                    preprocess=False,
                                    verbose=verbose)
            return


        if is_tuple(query) and is_tuple(query[0]) and query[0][0] in self.rules:
            # Handle rules as methods.
            pred, *args = query[0]
            env.debug_point("call", query)


            # TODO (dhatch): Ideally spy points would run via some hooks to
            # avoid polluting query logic with them.
            spied = pred in SPYPOINTS
            if spied:
                body_match = False
                context = " -> ".join(str(x[0] if is_tuple(x) else x)
                                     for x in env.trace()[1:])

            try:
                env.rule_stack.append(query[0])
                for match in self.rules[pred](*args, env=env, kb=self):
                    match.rule_stack.pop()

                    for result in self.query(query[1:],
                                             env=match,
                                             preprocess=False,
                                             verbose=verbose):
                        body_match = True
                        if spied:
                            print(f"{context} -> {result.subst(query[0])} -> true")

                        yield result

                    match.debug_point("retry", query)

                    if spied and not body_match:
                        print(f"{context} -> {match.subst(query[0])} -> false")
            except NoApplicableMethods:
                pass
            return

        # Handle nested tuples (often byproduct of excess parens)
        if is_tuple(query) and is_tuple(query[0]):
            for match in self.query(query[0], env, preprocess=False, verbose=verbose):
                yield from self.query(query[1:],
                                    env=match,
                                    preprocess=False,
                                    verbose=verbose)
            return

        if query == () or query == []:
            # This is how a successful query ends.
            yield env
            return


    def proof(self, query: tuple, *args, transform=None, **kwargs):
        """Produce proof (a trace) of a result from a query."""
        for env in self.query(query, *args, **kwargs):
            trace = env.trace(transform=transform)
            yield trace

    def verify(self, proof, query: tuple, *args, log=None, transform=None, **kwargs):
        """Verify proof (a trace) of a result from a query."""
        for env in self.query(query, *args, **kwargs):
            trace = env.trace(transform=transform)
            if proof and caveats(env, trace) and unify(proof, trace):
                if log:
                    log(query, env.trace())
                return True
            if log:
                log(query, None)
        return False

@dataclass
class UnificationSpecializer(Specializer):
    """A method argument specializer that selects based on
    unification of a pattern with the given query argument,
    possibly also with a type (class) restriction. The base
    pattern is stored here, but we rewrite it with fresh
    variables prior to unification."""
    pattern: Any = ()
    type: Optional[Union[Class, Group, Instance]] = None

    def __post_init__(self):
        # Look for a class-restricted pattern like (x: X).
        # Take x as the pattern, and X as the class restriction.
        if is_tuple(self.pattern) and len(self.pattern) == 3 and self.pattern[0] == ":":
            (_, pattern, restriction) = self.pattern
            self.pattern = pattern
            self.type = restriction if isinstance(restriction, Instance) or is_dict(restriction) else find_class(restriction)

    def is_applicable(self,
                      arg,
                      env: Environment = None,
                      kb: Facts = None,
                      pattern=None,
                      type=None,
                      source=None,
                      **kwargs):
        assert isinstance(env, Environment)
        arg = env.subst(arg)
        match: Match = env

        # Rewrite variables in the pattern and type, unless they
        # come in (already rewritten) on the keyword args from
        # PolarMethod.__call__.
        if pattern is None and self.pattern is not None:
            pattern = env.copy_vars(self.pattern)
        if type is None and self.type is not None:
            type = env.copy_vars(self.type)

        if type:
            if isinstance(type, Specializer):
                if not type.is_applicable(arg, env=env, **kwargs):
                    return False
            else:
                match = isa(arg, type, env)
                if not match:
                    return False

        return (match
                if pattern is None
                else isa(arg, pattern, cast(Environment, match), source=source))

    def is_subspecializer(self, other, arg, env: Environment = None, **kwargs):
        assert isinstance(env, Environment)
        if isinstance(other, type(self)):
            self_type = self.type or self.pattern
            other_type = other.type or other.pattern
            if isinstance(self_type, Specializer) and isinstance(other_type, Specializer):
                return self_type.is_subspecializer(other_type, arg, env=env, **kwargs)
            else:
                return isa(self_type, other_type, env)

        return False

@dataclass
class PolarMethod(Method):
    """A method with Polar (Prolog) predicate semantics:
    if the head unifies, query for the body."""

    source: Any = None
    code_context: Optional['CodeContext'] = None

    def __call__(self, *args, env: Environment = None, kb: Facts = None, **kwargs):
        assert isinstance(env, Environment), "invalid environment"
        assert isinstance(kb, Facts), "invalid KB"

        match, body = self.check_applicable(args, env, **kwargs)
        if isinstance(match, Environment):
            # Query for the body.
            yield from kb.query(body, env=match, source=self.source, preprocess=False)


    def is_applicable(self, args, env, **kwargs):
        match, _ = self.check_applicable(args, env, **kwargs)
        return match

    def check_applicable(self, args, env, **kwargs):
        # Make fresh variables for the free variables of both the (unification)
        # specializers and the body. This must be done all at once, so that the
        # same fresh variables are used for both.
        patterns, types, body = env.copy_vars(([getattr(spec, "pattern", ()) for spec in self.specs],
                                               [getattr(spec, "type", ()) for spec in self.specs],
                                               self.body))

        # Unify the args with the head.
        for (arg, spec, pattern, type) in zip(args, self.specs, patterns, types):
            match = spec.is_applicable(arg,
                                       env=env,
                                       pattern=pattern, type=type,
                                       source=self.source,
                                       **kwargs)
            if isinstance(match, Environment):
                env = match
            else:
                return False, None

        return match, body

if __name__ == "__main__":
    from doctest import testmod
    (failures, tests) = testmod(verbose=True)
    if failures > 0:
        exit(failures)
