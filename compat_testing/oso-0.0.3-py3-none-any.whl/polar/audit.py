from contextlib import closing, contextmanager
import io
import logging
import os
import pickle
from datetime import datetime, timezone
from sqlite3 import Connection, IntegrityError
from typing import Any, Dict

from polar.classes import Instance

logger = logging.getLogger(__name__)

# Audit logs are an unstable feature
ENABLE_AUDIT = False

def enable():
    global ENABLE_AUDIT
    ENABLE_AUDIT = True

class Unknown:
    fields: Dict[str, Any] = {}

    def __setstate__(self, dict):
        self.fields = dict

    def __str__(self):
        return f"{self.__class__.__name__}{{{', '.join(f'{k}: {v}' for k, v in self.fields.items())}}}"

class LenientUnpickler(pickle.Unpickler):
    """Attempts to unpickle, but falls back to an unknown class if it raises an exception"""
    def find_class(self, module, name):
        try:
            return super(LenientUnpickler, self).find_class(module, name)
        except Exception as e:
            logger.error(f"Could not find class {name} in module {module}")
            logger.exception(e)
            cls = type(name, (Unknown, ), {})
            return cls

def load(s):
    return LenientUnpickler(io.BytesIO(s)).load()

class AuditEntry:
    """class to store audit logs"""
    def __init__(self, row: tuple):
        self.id = row[0]
        self.timestamp = row[1]
        self.result = True if row[2] == 1 else False
        query = load(row[3])
        self.actor = query.args[0]
        self.action = query.args[1]
        self.resource = query.args[2]
        self.trace = load(row[4])

class AuditLog:
    def __init__(self):
        self.db_path = os.getenv("DB_PATH")
        if not self.db_path:
            raise ValueError("Please initialize the AuditLog with the path to a SQLite3 DB.")
        with self._cursor() as cur:
            cur.execute("CREATE TABLE IF NOT EXISTS events "
                            "(id INTEGER NOT NULL PRIMARY KEY,"
                            " timestamp DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,"
                            " result BOOLEAN NOT NULL CHECK (result IN (0,1)),"
                            " query BLOB NOT NULL,"
                            " trace BLOB NOT NULL   "
                            ");")

    @contextmanager
    def _cursor(self):
        with closing(Connection(self.db_path)) as conn:
            with conn:
                with closing(conn.cursor()) as cur:
                    yield cur

    def write(self, event: tuple):
        with self._cursor() as cur:
            cur.execute("INSERT INTO events (timestamp, result, query, trace) "
                                  "VALUES (?, ?, ?, ?)", event)

    def iter(self):
        with self._cursor() as cur:
            for row in cur.execute("SELECT * FROM events"):
                yield AuditEntry(row)

    def get(self, id: int = 0):
        with self._cursor() as cur:
            result = cur.execute("SELECT * FROM events WHERE id = ?", (id,)).fetchone()
            if not result:
                return None
            return AuditEntry(result)

    def count(self):
        with self._cursor() as cur:
            return cur.execute("SELECT count(*) FROM events").fetchone()[0] + 1

    def clear(self):
        with self._cursor() as cur:
            cur.execute("DELETE from events")

def log(query, trace=None):
    logger.debug(f"Auditing is enabled={ENABLE_AUDIT}")
    if ENABLE_AUDIT:
        try:
            timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            result = 1 if trace else 0
            trace = pickle.dumps(trace)
            query = pickle.dumps(query)
            AuditLog().write((timestamp, result, query, trace))
        except ValueError as e:
            logger.debug("no audit DB configured; cannot log event")
        except Exception as e:
            logger.exception(e)
