import pytest

from .facts import Fact, Facts, rewrite_lookups

# TODO (dhatch): Parse variables

def fact(*params):
    head = params
    return (head,)

def rule(head, *body):
    return (head, *body)

@pytest.mark.parametrize("input,expected", [
    (
        fact("test1", "?d", (".", "?d", "k")),
        rule(("test1", "?d", "?_v_1"), (".", "?d", "k", "?_v_1")),
    ),
    (
        rule(("rule1", "?d"), ("=", (".", "?d", "k"), "1")),
        rule(("rule1", "?d"), (".", "?d", "k", "?_v_1"), ("=", "?_v_1", "1"))
    ),
    (
        fact("test", "?d", (".", (".", "?d", "foo"), "bar")),
        rule(("test", "?d", "?_v_2"), (".", "?d", "foo", "?_v_1"), (".", "?_v_1", "bar", "?_v_2"))
    ),
    (
        fact("attr", (".", {"a": (".", "?d", "b")}, "a"), "foo", "bar"),
        rule(("attr", "?_v_2", "foo", "bar"), (".", "?d", "b", "?_v_1"), (".", {"a": "?_v_1"}, "a", "?_v_2"))
    ),
])
def test_attrs_rewrite(input, expected):
    # We mock this so variable generation is predictable
    class MockKb:
        i = 1

        @classmethod
        def variable(cls, _):
            var = f"?_v_{cls.i}"
            cls.i += 1
            return var

    assert rewrite_lookups(input, MockKb) == expected
