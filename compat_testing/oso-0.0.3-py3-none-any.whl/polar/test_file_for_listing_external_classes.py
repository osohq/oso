from dataclasses import dataclass, field
from frozendict import frozendict
from typing import Dict, List, Tuple

from polar.api import register_class, ClassSpecification, Http, Polar

# Fake global actor name → company ID map.
# Should be an external database lookup.
actors = {
    "guest": "1",
    "president": "1",
}

@dataclass(frozen=True)
class Actor:
    name: str = ""

    def company(self):
        yield Company(id="0") # fake, will fail
        yield Company(id=actors[self.name]) # real, will pass

    def beep(self, foo: Tuple[float, Dict[str, Http]]):
        pass

@dataclass(frozen=True)
class Widget:
    # Data fields.
    id: str = ""
    doodad: float = 0.0
    doohickey: Tuple[float, int] = (0.0, 0)

    # Class variables.
    actions = ("get", "create")

    def company(self):
        yield Company(id=self.id)

register_class(ClassSpecification("Widget", ["id", "doodad", "doohickey"], ["company"], []), Widget)

widget_maps = frozendict({
    ("get", Http(path="/widget/{id}")): ("get", Widget(id="{id}")),
    ("post", Http(path="/widget/")): ("create", Widget(id="0")),
})


@dataclass(frozen=True)
class Company:
    # Data fields.
    id: str = ""
    default_role: str = ""
    ceo: Actor = field(default_factory=Actor)
    cto: Actor = field(default_factory=Actor)
    employees: List[Actor] = field(default_factory=list)

    # Class variables.
    roles = ("guest", "admin")

    def role(self, actor: Actor):
        if actor.name == "president":
            yield "admin"
        else:
            yield "guest"

register_class(ClassSpecification("Company", ["id", "default_role", "ceo", "cto", "employees"], ["role"], []), Company)


default_company = Company(id="1", default_role="admin")

def load(kb):
    polar = Polar()
    polar._kb = kb
    polar.register_mappings(widget_maps)
