import pytest

from polar.api import register_class, ClassSpecification, Polar, to_polar
from polar.classes import class_of, find_class
from polar.facts import make_env, unify
from polar.parser import Variable, parse
from polar.policy import Facts, Http, external_resource_map

from dataclasses import field, dataclass
from frozendict import frozendict

@pytest.fixture
def kb():
    return Facts(variable=Variable)

@dataclass(eq=True, frozen=True)
class Repository:
    id: str = ""
    sub: str = ""
    roles: tuple = ("reader", "writer")
    actions: tuple = ("read", "list", "create", "create_branch")

register_class(ClassSpecification("Repository", ["id","sub"], [], []), Repository)

repository_maps = frozendict({
    ("get", Http(path="/repository/{id}")): ("read", Repository(id="{id}")),
    ("post", Http(path="/repository/{id}/branch")): ("create_branch", Repository(id="{id}"))
})

def test_policy(kb):
    """Bad test that uses the github example.

    Add more later!
    """
    polar = Polar()
    polar._kb = kb
    polar.register_mappings(repository_maps)

    # test resourceMapping loaded into kb properly
    resource_mappings = [
        (e['from'], e['to'])
        for e in kb.query(parse("resourceMapping(from, to)"))
    ]

    assert len(resource_mappings) == 2

    # test resource mapping query using dictionary unification
    http_mappings = kb.query(parse("resourceMapping((action, spec), "
                                                   "(result_action, result_spec)), "
                                   "path = spec.path,"
                                   "isa(result_spec, result_kind)"))
    mapping_vars = next(http_mappings)
    assert unify(to_polar(Repository(id="1")),
                 next(external_resource_map('/repository/1',
                                                            mapping_vars['path'],
                                                            mapping_vars['result_kind'],
                                                            mapping_vars['result_spec'])))

def test_external_resource_map():
    url = "/repository/"
    url_spec = "/repository/"
    result_kind = find_class("Repository")
    result_spec = {}

    def extmap(default=False):
        return next(external_resource_map(url, url_spec, result_kind, result_spec),
                                          default)

    assert class_of(extmap()) is result_kind

    url = "/repository/1/"
    url_spec = "/repository/{id}/"
    result_kind = find_class("Repository")
    result_spec = {"id": "{id}"}
    assert unify(extmap(), to_polar(Repository(id="1")))

    url = "/notarepository/1/"
    assert not extmap()

    url = "/repository/1/nope"
    assert not extmap()

    url = "/repository/1/other/2"
    url_spec = "/repository/{id}/other/{sub_id}"
    result_spec = {"id": "{id}", "sub": "{sub_id}"}
    assert unify(extmap(), to_polar(Repository(id="1", sub="2")))

    url = "/repository/1/other/2/trail"
    assert not extmap()

    url = "/repository/1/wrong/2/"
    assert not extmap()
