from pytest import raises
from dataclasses import dataclass

from polar.classes import Class, class_of, Field, FieldError, GenericPredicate, LinearizationError, Method, NoApplicableMethods, Object

def test_subclass():
    a = Class("a")
    b = Class("b")
    x = Class("x", (a, b))
    y = Class("y", (x,))
    assert x.is_subclass(a)
    assert y.is_subclass(b)
    assert not x.is_subclass(y)

def test_mro():
    """From Wikipedia: C3 linearization"""
    a = Class("a")
    b = Class("b")
    c = Class("c")
    d = Class("d")
    e = Class("e")
    k1 = Class("k1", (a, b, c))
    k2 = Class("k2", (d, b, e))
    k3 = Class("k3", (d, a))
    z = Class("z", (k1, k2, k3))
    assert z.cpl == (z, k1, k2, k3, d, a, b, c, e, Object)

def test_mro_fail():
    """Guido's example from
    <http://python-history.blogspot.com/2010/06/method-resolution-order.html>"""
    a = Class("a")
    b = Class("b")
    x = Class("x", (a, b))
    y = Class("y", (b, a))
    with raises(LinearizationError):
        z = Class("z", (x, y))

def test_fields():
    Foo = Class("Foo", (), (Field("foo"),))
    Bar = Class("Bar", (Foo,), (Field("bar", Foo), Field("foo", Foo),))
    Baz = Class("Baz", (Bar,), (Field("bar", Bar),)) # tighten restriction on bar
    foo = Foo("Foo!")
    bar = Bar(foo, foo)
    baz = Baz(foo, bar)
    assert class_of(foo) is Foo and foo.foo == "Foo!"
    assert class_of(bar) is Bar and bar.foo is foo and bar.bar is foo
    assert class_of(baz) is Baz and baz.foo is foo and baz.bar is bar
    with raises(FieldError):
        Baz(foo, foo) # doesn't fulfill restriction on bar
    # @TODO: ALEX
    # with raises(FieldError):
    #     Class("Quux", (Bar,), (Field("bar"),)) # can't relax restriction on bar

@dataclass
class TestMethod(Method):
    # This prevents the class from being collected by Pytest -- it's a method class for tests
    __test__ = False

    def __call__(self, *args, **kwargs):
        return self.body

def test_method():
    a = Class("a")
    b = Class("b")
    c = Class("c")
    aa = Class("aa", (a,))
    ab = Class("ab", (a, b))
    ac = Class("ac", (a, c))
    abc = Class("abc", (ab, ac))
    acb = Class("acb", (ac, ab))
    f = GenericPredicate("f")
    m1 = TestMethod(f, params=("a",), specs=(a,), body=("A",))
    m2 = TestMethod(f, params=("a",), specs=(aa,), body=("AA",))
    m3 = TestMethod(f, params=("a",), specs=(ab,), body=("AB",))
    m4 = TestMethod(f, params=("a",), specs=(ac,), body=("AC",))
    assert list(f(a())) == ["A"]
    assert list(f(aa())) == ["AA", "A"]
    assert list(f(ab())) == ["AB", "A"]
    assert list(f(ac())) == ["AC", "A"]
    assert list(f(abc())) == ["AB", "AC", "A"]
    assert list(f(acb())) == ["AC", "AB", "A"]
    with raises(NoApplicableMethods):
        assert next(f(b()))
