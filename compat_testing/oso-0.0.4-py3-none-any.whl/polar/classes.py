"""Metaobjects for classes, generic predicates, and methods.
They are "metaobjects" because they are objects (in the host language)
that represent objects and classes (in the target language).
The behavior of these metaobjects controls the (target language)
behavior of inheritance, method applicability, and call semantics.
Organizing them as classes (in the host language) allows easy
extension and customization through subclassing; see "The Art of
the Metaobject Protocol" by Kiczales, Rivières, and Bobrow (1991)."""

from abc import ABC, abstractmethod
import builtins
from c3linearize import build_graph, linearize, Error as LinearizationError
from collections import OrderedDict
from dataclasses import dataclass, field
from functools import cmp_to_key
from typing import cast, Any, Dict, List, Optional, Tuple, Union, Callable
from frozendict import frozendict

from polar.exceptions import PolarRuntimeException
from polar.polar_types import map_tree

class InitError(PolarRuntimeException): pass
class FieldError(PolarRuntimeException): pass
class NoApplicableMethods(PolarRuntimeException): pass
class NoSuchClass(PolarRuntimeException): pass

class Specializer(ABC):
    """A metaobject used to determine applicability of a method
    with respect to a particular argument."""

    @abstractmethod
    def is_applicable(self, arg, **kwargs):
        """Return true if this specializer selects for the given argument."""
        pass

    @abstractmethod
    def is_subspecializer(self, other, arg, **kwargs):
        """Return true if this specializer is more specific than another
        with respect to the given argument. Used to sort methods in
        specificity order."""
        pass

@dataclass(unsafe_hash=True)
class Class(Specializer):
    """A class metaobject has a name, a tuple of superclass metaobjects,
    a tuple of field metaobjects, and a class precedence list (CPL; also
    a tuple of class metaobjects) computed from the superclasses at class
    initialization time."""

    name: str
    supers: Tuple['Class', ...] = ()
    fields: Tuple['Field', ...] = ()
    cpl: Tuple = field(default_factory=tuple, hash=False)
    check_fields: bool = True

    def make_instance(self, *args, **kwargs) -> 'Instance':
        """Instantiate the class."""
        return Instance(self, frozendict(kwargs))

    def __repr__(self):
        return f"<{self.name}>"

    def __str__(self):
        return repr(self)

    def __post_init__(self):
        # Default the superclass list to Object, except for Object
        # (to avoid infinite regress).
        if not self.supers and self.name != "Object":
            self.supers = tuple(self.supers) or (Object,)

        # Coerce the fields to a tuple so they're hashable
        # for computing the CPL. We'll compute the full list
        # of inherited fields afterwards.
        self.fields = tuple(self.fields)

        # Determine the class precedence list, if possible,
        # using the C3 linearization algorithm ("A Monotonic
        # Superclass Linearization for Dylan" by K. Barrett,
        # et al., OOPSLA'96). This may throw a LinearizationError
        # if no consistent CPL exists.
        dependency_graph = build_graph(self, lambda x: x.supers)
        self.cpl = tuple(linearize(dependency_graph)[self])

        # Sanity check the CPL.
        assert self.cpl[0] is self, "invalid class linearization"
        if self.name != "Object": # so we can redefine Object
            assert self.cpl[-1] is Object, "everything is an Object"

        # Inherit fields in reverse precedence order.
        fields = OrderedDict()
        for sup in reversed(self.cpl):
            for field in sup.fields:
                if (field.type and
                    field.name in fields and
                    fields[field.name].type and
                    hasattr(field.type, "is_subclass") and # FIXME: yuck
                    not field.type.is_subclass(fields[field.name].type)):
                    raise FieldError("can only restrict field types in a subclass")
                fields[field.name] = field
        self.fields = tuple(fields.values())

    def __getitem__(self, name):
        """Look up a field by name."""
        for field in self.fields:
            if field.name == name:
                return field
        raise FieldError(f"{self.name} instances do not have a {name} field")

    def is_subclass(self, other, **kwargs):
        return other in self.cpl

    def is_applicable(self, arg, **kwargs):
        try:
            return class_of(arg).is_subclass(self)
        except AttributeError:
            return False

    def is_subspecializer(self, other, arg, **kwargs):
        """Adapted from `sub-specializer-p` in AMOP §1.8.1."""
        cpl = class_of(arg).cpl
        return (other not in cpl or # for non-class specializers, e.g., groups
                other in cpl[cpl.index(self):])

Object = Class("Object")
CLASSES: Dict[str, Specializer] = {"Object": Object}

@dataclass
class Instance:
    """An instance metaobject. Stores a type (class metaobject)
    and a dictionary of field values."""
    type: Specializer = Object
    fields: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        # fields don't exist on ExternalInstances, so this only executes for Polar Instances
        for name, value in self.fields.items():
            field = self.type[name]
            try:
                if isinstance(value, Instance) and field.type and not field.type.is_applicable(value):
                    raise FieldError(f"{value} is not of type {field.type}, "
                                     f"as required by field {self.type.name}.{field.name}")
            except AttributeError:
                # E.g., for variables, which don't have an is_subclass method.
                # FIXME: this catches too much, e.g., Python built-in classes.
                pass

    def __str__(self):
        return f"{self.type.name}{{{', '.join(f'{k}: {v}' for k, v in self.fields.items())}}}"

    def map(self, f: Callable) -> 'Instance':
        """ Mapping method for type Instance"""
        copy = cast(Class, self.type).make_instance(**{k: map_tree(f, v) for k, v in self.fields.items()})
        return copy

    def get_field(self, field, args=None, **kwargs):
        try:
            yield self.fields[field]
        except KeyError:
            raise PolarRuntimeException(f"{self} does not have field {field}")

def class_fields(cls) -> Tuple:
    if isinstance(cls, Class):
        return cls.fields
    elif isinstance(cls, type):
        return tuple(Field(name, Object)
                     for name in cls.__dict__.keys()
                     if not name.startswith("_"))
    else:
        assert False, f"can't list fields of {cls}"

def class_name(cls) -> str:
    """Return the name of a class."""
    if isinstance(cls, Class):
        return cls.name
    elif isinstance(cls, type):
        return cls.__name__
    else:
        return class_name(type(cls))

def class_of(x):
    """Return the class of x, unless it is a class,
    in which case it designates itself."""
    if isinstance(x, (Class, type)):
        return x
    elif isinstance(x, Instance):
        return x.type
    elif isinstance(x, object):
        return type(x)
    else:
        return Object

def find_class(name):
    """Find a class by name. Classes designate themselves.
    Raise a `NoSuchClass` exception if the class is not found."""
    if isinstance(name, Class):
        return name

    # Check for a built-in class, e.g., bool, int, str.
    if isinstance(name, str) and hasattr(builtins, name):
        cls = getattr(builtins, name)
        if isinstance(cls, type):
            return cls
        else:
            raise NoSuchClass(f"can't find class {name}")

    # Look up the class by name in the global registry.
    try:
        return CLASSES[name]
    except KeyError:
        raise NoSuchClass(f"can't find class {name}")

@dataclass(frozen=True)
class Field:
    """A typed field metaobject. Note that this does not store
    the value of a field. Instead, it describes the field itself
    and the type (class) of any such value."""
    name: str
    type: Optional[Union[Class,type]] = None

@dataclass
class GenericPredicate:
    """A generic predicate (analogous to a generic function in Common Lisp)
    with methods that may be specialized on the types, etc. of the arguments
    supplied to a call. At call time, we select the applicable methods, sort
    them in most- to least-specific order, and call them."""

    name: str
    methods: List['Method'] = field(default_factory=list)

    def __call__(self, *args, **kwargs):
        applicable_methods = [method
                              for method in self.methods
                              if method.is_applicable(args, **kwargs)]
        if not applicable_methods:
            raise NoApplicableMethods(f"{self.name} has no methods applicable to {args}")

        def is_more_specific(m1, m2):
            return (0 if m1.specs == m2.specs else
                   -1 if m1.is_more_specific(m2, args, **kwargs) else
                    1)
        applicable_methods.sort(key=cmp_to_key(is_more_specific))

        for method in applicable_methods:
            yield from method(*args, **kwargs)

            # WOW, CUT HACK!
            if getattr(self, "cut", False):
                setattr(self, "cut", False)
                break

@dataclass
class MethodFields:
    """The generic predicate, parameters, specifiers, and body of a method."""
    predicate: GenericPredicate
    params: Tuple = ()
    specs: Tuple = ()
    body: Tuple = ()

class Method(MethodFields, ABC):
    """An abstract method. Contains an implementation of a generic
    predicate for a specified set of arguments. Called only by that
    generic predicate when the given arguments are applicable, as
    determined by our specifiers."""

    @abstractmethod
    def __call__(self, *args, **kwargs):
        pass

    def __post_init__(self):
        self.params = tuple(self.params)
        self.specs = tuple(spec or Object
                           for spec in self.specs or [None for _ in self.params])
        assert len(self.params) == len(self.specs), \
            "parameters and specifiers don't agree"
        self.body = tuple(self.body)

        # Ensure that this method is registered with its GP.
        if self not in self.predicate.methods:
            self.predicate.methods.append(self)

    def __repr__(self):
        return f"{self.predicate.name}{tuple(spec for spec in self.specs)}"

    @abstractmethod
    def is_applicable(self, args, **kwargs):
        """Return true if this method is applicable to the given arguments."""
        pass

    def is_more_specific(self, other, args, **kwargs):
        """Return true if this method is more specific than another
        with respect to the given arguments. Adapted from
        `method-more-specific-p` in AMOP §1.8.1."""
        for (spec1, spec2, arg) in zip(self.specs, other.specs, args):
            if spec1 != spec2:
                more_specific = spec1.is_subspecializer(spec2, arg, **kwargs)
                if more_specific:
                    return True
        return False
