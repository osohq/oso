"""Merkle trees."""

from abc import ABC, abstractmethod
from binascii import hexlify
from functools import reduce
from hashlib import sha256
from hmac import HMAC
from operator import add
from os import urandom
from types import FunctionType

def nonce(size=32):
    """A random number, size bytes long.
    Suitable as a globally unique identifier,
    a secret key, or a random initial value.

    >>> len(nonce(32)) == 32
    True
    >>> isinstance(nonce(), bytes)
    True
    >>> nonce() != nonce()
    True
    """
    assert size >= 16, "nonce too small"
    return urandom(size)

def H(key, data, hashfun=sha256):
    """HMAC/SHA-256 keyed hash message authentication code.
    Returns a 256-bit byte string.

    >>> len(H(b'secret', b'data', hashfun=sha256)) == 32
    True
    >>> isinstance(H(b'secret', b'data'), bytes)
    True
    >>> H(b'secret', b'data') == H(b'secret', b'data')
    True
    >>> H(b'secret', b'data') != H(b'secret*', b'data')
    True
    >>> H(b'secret', b'data') != H(b'secret', b'data*')
    True
    """
    return HMAC(key, data, hashfun).digest()

def Hex(key, data, hashfun=sha256):
    """Hex representation of the default keyed hash MAC.
    Each byte of the MAC is encoded as two bytes of ASCII
    encoded hex digits, making the string twice as long
    but much easier to read.

    >>> h = Hex(nonce(), nonce()).decode('ascii')
    >>> len(h) == 64
    True
    >>> import re
    >>> re.match(r'^[0-9a-f]+$', h).group(0) == h
    True
    """
    return hexlify(H(key, data, hashfun))

def to_bytes(object, encoding="utf-8"):
    """Convert an integer or string-like object to a byte string.

    >>> to_bytes('1234') == b'1234'
    True
    >>> to_bytes(b'1234') == b'1234'
    True
    >>> to_bytes(0xdeadbeef) == b'deadbeef'
    True
    """
    if isinstance(object, bytes):
        return object
    elif isinstance(object, str):
        return object.encode(encoding)
    elif isinstance(object, int):
        return bytes(f"{object:x}", "ascii")

def to_string(data):
    """Convert a byte string to an ASCII string representation.

    >>> to_string(b'1234') == '1234'
    True
    >>> to_string(b'deadbeef') == 'deadbeef'
    True
    >>> to_string(b'\x12\x34') == '1234'
    True
    """
    assert isinstance(data, bytes)
    if data.isalnum():
        return data.decode("ascii")
    else:
        return data.hex()

from operator import attrgetter
sig = attrgetter("sig") # = lambda x: x.sig

class MAC:
    """An object with a message authentication code, or MAC.
    This could be the output of a keyed hash function,
    a private key signature, etc. Stores a key and a MAC
    (e.g., HMAC with an underlying hash function like SHA)
    as a function of two arguments: a key and some data."""

    def __init__(self, key=b"", mac=H, **kwargs):
        assert isinstance(key, bytes)
        assert isinstance(mac, FunctionType)
        self.key = key
        self.mac = mac

    @property
    @abstractmethod
    def sig(self):
        """Compute a message authentication code or signature."""
        pass

    def __str__(self):
        """Convert the signature to a string."""
        return to_string(self.sig)

class Leaf(MAC):
    """A leaf of a Merkle tree. Stores a blob of data (a byte string)
    and a parent Node. Its signature is over the data only, but we use
    the key prefixing scheme from Certificate Transparency "to give
    second preimage resistance" (RFC 6962 §2.1).

    >>> Leaf(mac=Hex).sig
    b'7ee63503c8fd03ddf6f3cefd998f4aaf56329811f10b779043e8d05cb0e76de5'
    >>> Leaf(data=b'data', mac=Hex).sig
    b'304f72a4613f6793fb677978f943ebce7eeb351036950e28f4320fe6c31fd7ea'
    """

    def __init__(self, data=None, parent=None, key=b"0", **kwargs):
        if key != b"0":
            key = b"0" + key # derive a new key, but differently than Node
        super().__init__(key=key, **kwargs)

        self.data = to_bytes(data) or b""
        self.parent = parent

    @property
    def sig(self):
        """Hash the data with our key."""
        return self.mac(self.key, self.data)

    def __eq__(self, other):
        return self.sig == other.sig

    def __repr__(self):
        return f"{self.__class__.__name__}({self.data})"

class Node(MAC):
    """A node of a Merkle tree. Stores a list of children and a parent Node,
    or None if it is a root. Its signature is over all of its children.

    >>> Node(mac=Hex).sig
    b'49f41477fa1bfc3b4792d5233b6a659f4bc1772692e9d5fe7db0624a300652eb'
    """

    def __init__(self, children=[], parent=None, key=b"1", **kwargs):
        if key != b"1":
            key = b"1" + key # derive a new key, but differently than Leaf
        super().__init__(key=key, **kwargs)

        self.children = []
        for child in children:
            self.add_child(child)

        self.parent = parent
        if parent:
            parent.add_child(self)

    def add_child(self, child, **kwargs):
        """Add a child of this Node. If it is not a Leaf or a Node,
        treat it as data and wrap it in a Leaf.

        >>> root = Node(mac=Hex)
        """
        if isinstance(child, (Leaf, Node)):
            child.parent = self
        else:
            child = Leaf(data=child, parent=self, mac=self.mac, **kwargs)
        self.children.append(child)
        return child

    @property
    def sig(self):
        """Hash the concatenated signatures of the children."""
        return self.mac(self.key,
                        reduce(add, [child.sig for child in self.children], b""))

    def __eq__(self, other):
        return self.sig == other.sig

    def __getitem__(self, index):
        return self.children[index]

    def __iter__(self):
        return iter(self.children)

    def __repr__(self):
        return f"{self.__class__.__name__}({list(self.children)})"

    def graph(self):
        from graphviz import Digraph
        dot = Digraph(comment="Merkle Tree")
        def graph(node, parent=None):
            sig = str(node)
            dot.node(sig, sig)
            if parent:
                dot.edge(parent, sig)
            if isinstance(node, Node):
                for child in node:
                    graph(child, sig)
            else:
                dot.node(sig, to_string(node.data), shape="square")
        graph(self)
        dot.render(str(self), view=True)

if __name__ == "__main__":
    from doctest import testmod
    (failures, tests) = testmod(verbose=True)
    if failures > 0:
        exit(failures)
