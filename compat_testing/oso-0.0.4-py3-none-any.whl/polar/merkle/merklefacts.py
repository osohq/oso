from ..facts import Fact, Facts
from .merkle import H, Hex, Leaf, Node, MAC, sig

class MerkleFacts(Facts, MAC):
    """A knowledge base where every clause has an entry in a Merkle tree.

    >>> from polar.parser import load, parse
    >>> kb = MerkleFacts(mac=lambda k, x: Hex(k, x)[:6])
    >>> load("tests/test_policies/functions.pol", kb) is kb
    True
    >>> len(kb.facts)
    6
    >>> kb.sig
    b'379c8c'
    >>> tuple(map(sig, kb.facts))
    (b'cb7feb', b'0b1dc4', b'eb0f93', b'43b8cd', b'e8b814', b'66361c')
    >>> proof = next(kb.proof(parse("k(x)"))); proof
    (b'379c8c', b'66361c', b'0b1dc4', b'43b8cd', b'e8b814')
    >>> kb.verify(proof, parse("k(x)"))
    True
    >>> kb.verify(proof, parse('k("b")'))
    True
    >>> kb.verify(proof, parse('k("a")'))
    False
    """

    def __init__(self, *args, parent=None, mac=H, **kwargs):
        super().__init__(*args, **kwargs)
        self.root = Node(parent=parent, mac=mac)

    def tell(self, fact):
        def add_node(fact, parent=self.root):
            if isinstance(fact, tuple):
                node = parent.add_child(Node(mac=parent.mac))
                for child in fact:
                    add_node(child, parent=node)
                return node
            else:
                return parent.add_child(fact)
        node = add_node(fact)

        try:
            fact.sig = node.sig
        except AttributeError:
            # Wrap the fact so we can store a signature.
            fact = Fact(fact)
            fact.sig = node.sig

        return super().tell(fact)

    @property
    def sig(self):
        return self.root.sig

    @staticmethod
    def transform(x):
        if isinstance(x, list) and len(x) == 2:
            # assume fact, caveat
            return (x[0].sig, x[1])
        elif hasattr(x, "sig"):
            return x.sig
        else:
            return x

    def proof(self, query, *args, **kwargs):
        for proof in super().proof(query, *args, **kwargs,
                                   transform=self.transform):
            yield proof

    def verify(self, proof, query, *args, **kwargs):
        transform = kwargs.pop("transform", self.transform)
        return super().verify(proof, query, *args, **kwargs,
                              transform=transform)

if __name__ == "__main__":
    from doctest import testmod
    (failures, tests) = testmod(verbose=True)
    if failures > 0:
        exit(failures)
