"""Faked Out Polar Language API.
Exposed to other host languages, e.g. Python"""

from abc import ABC
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from frozendict import frozendict
import inspect
import json
import logging
import os
import re
from pathlib import Path
from typing import Dict, List, Tuple as TupleType, Any, Sequence, Type, Union, Optional, Callable
from types import BuiltinMethodType, MethodType

from polar.audit import log, AuditLog
from polar.classes import CLASSES, class_of, find_class, Field, Instance, NoSuchClass, Object, Specializer
from polar.exceptions import UnboundVariable, PolarRuntimeException, PolarApiException
from polar.facts import Environment, Fact, Facts, copy_fact, Variable, Match
from polar.parser import load, parse, Tuple, String, Number, Boolean
from polar.polar_types import is_tuple, is_dict, map_tree

logger = logging.getLogger(__name__)

POLAR_TYPES = [int, float, bool, str, dict, type(None), Instance, Specializer, Variable, frozendict]

# Per-query instance cache from Polar Instance -> Python Instance
CACHE_KEY_COUNTER: int = 0
PYTHON_INSTANCE_CACHE: Dict[int, object] = {}

# Map from Python class name to external classes.
EXTERNAL_CLASSES: Dict[str, type] = {}


@dataclass
class Query:
    """Request type for a `query` API call.

    :param name: the predicate to query
    :param args: a list of arguments to the predicate
    """
    name: str
    args: Sequence[Any]

class QueryResult:
    """Response type of a call to the `query` API"""
    def __init__(self, results: list):
        self.results = results
        self.success = len(results) > 0

@dataclass(frozen=True)
class ClassSpecification:
    """Specification for defining a Polar class"""
    name: str = ""
    parents: TupleType = ()
    from_polar: str = ""
    # maps: {} = frozendict({}) # @TODO: maybe include this in the spec?

###### API Implementation details below

class Polar:
    """Polar API class"""
    _kb: Facts
    load_queue: List[Path]

    def __init__(self, kb: Facts = None):
        """Initialize Polar
        Client: call some init API method?
        server: initialize KB as here"""

        self._kb = kb or Facts()
        self.load_queue = []

    def import_builtin_module(self, name: str):
        """Import a builtin polar module

        Client: send name to Polar
        Polar:  same as it is here
        """
        load(Path(__file__).parent / "policies" / f"{name}.polar", self._kb)

    def _kb_load(self):
        """ Load queued policy files into the knowledge base."""
        files = self.load_queue.copy()
        for policy_file in files:
            self.load_queue.remove(policy_file)
            load(policy_file, self._kb)

    def load(self, policy_file):
        """Load in polar policies. By default, defers loading of knowledge base
        until a query is made.

        Client: read in file as string and send to polar
        Polar:  take in string and add to KB
        """

        policy_file = Path(policy_file)

        extension = policy_file.suffix
        if extension != ".pol" and extension != ".polar":
            raise PolarApiException(f"Policy names must have .pol or .polar extension")

        if not policy_file.exists():
            raise PolarApiException(f"Could not find file: {policy_file}")

        if policy_file not in self.load_queue:
            self.load_queue.append(policy_file)


    def clear(self):
        """ Clear all facts and internal Polar classes from the knowledge base."""
        self.load_queue = []
        self._kb = Facts()
        # un-register all non-external classes
        internal_classes = set(CLASSES.keys()) ^ set(EXTERNAL_CLASSES.keys())
        for name in internal_classes:
            del CLASSES[name]


    def query(self, query: Query, debug=False) -> QueryResult:
        """Query the knowledge base.

        Client: Serialize inputs and send, handle query response(s).
        Polar:  Deserialize inputs, and query (implemented here)."""
        # Make sure all policy files are loaded
        self._kb_load()

        # flush instance cache before each query
        global PYTHON_INSTANCE_CACHE
        # we aren't clearing the counter for now because `register_mappings` calls `to_polar()`
        # outside of `query()`
        # CACHE_KEY_COUNTER = 0
        PYTHON_INSTANCE_CACHE = {}

        new_args = []
        for arg in query.args:
            new_args.append(self.to_polar(arg))

        tuplified_query: TupleType[Any, ...] = ((query.name, ) + tuple(new_args),)
        if debug:
            tuplified_query = (("debug",),) + tuplified_query

        results = list(self._kb.query(tuplified_query))
        result =  QueryResult(results)
        if result.success:
            log(query, result.results[0].trace())
        else:
            log(query)
        return result

    def to_python(self, polar_instance):
        return to_external(polar_instance)

    def to_polar(self, python_instance):
        """Convert Python object `python_instance` to Polar `Instance`"""
        # This type check is exact because we want any type that is defined
        # externally to be converted to a polar instance.
        if type(python_instance) in POLAR_TYPES:
            if type(python_instance) is bool:
                return Boolean(python_instance)
            return python_instance

        name = python_instance.__class__.__name__

        try:
            cls = find_class(name)
        except NoSuchClass:
            # Register the class automatically.
            self.register_python_class(python_instance.__class__)
            cls = find_class(name)

        polar_instance = cls.make_instance()

        # store python instance in cache
        global CACHE_KEY_COUNTER
        CACHE_KEY_COUNTER = CACHE_KEY_COUNTER + 1
        PYTHON_INSTANCE_CACHE[CACHE_KEY_COUNTER] = python_instance
        polar_instance.instance_cache_key = CACHE_KEY_COUNTER

        return polar_instance

    def register_python_class(self, cls, from_polar=None):
        """Python-side implementation of the `register_class` API.

        Makes an external class and its associated fields and methods accessible
        from within a Polar policy.

        :param list[str] cls: The class type to be registered.
        :param list[str] fields: Names of class fields to expose to Polar; will default to all fields.
        :param list[str] methods: Names of class methods to expose to Polar; will default to all class methods.
        :param str from_polar: Name of static class function to create a new class instance from ``fields``.
                                Defaults to class constructor.

        :return: None

        Example::

            class ExternalClass:
                def __init__(self, id):
                    self.id = id
                def my_method(self): ...

            register_python_class(cls=ExternalClass, fields=["id"])

        """


        from_polar = from_polar or ""

        spec = ClassSpecification(
            name=cls.__name__,
            parents=(),
            from_polar=from_polar
            )

        EXTERNAL_CLASSES[spec.name] = cls
        polar_cls = ExternalClass(spec=spec, source_class=cls, name=spec.name)
        CLASSES[spec.name] = polar_cls
        return cls


def instantiate_externals(term, **kwargs):
    """Replace native instance with external instances.
    Instantiate externals in the instance data and args,
    instantiate host class, and do the lookup/call manually.
    All this should move to oso."""
    def rewrite(term):
        if isinstance(term, Instance):
            return to_external(term, **kwargs)
        elif is_dict(term):
            return copy_fact(term, {k: rewrite(v) for k, v in term.items()})
        elif is_tuple(term):
            return copy_fact(term, (rewrite(x) for x in term))
        elif isinstance(term, Boolean):
            return term.val
        else:
            return term
    return rewrite(term)

def result_to_generator(result):
    if type(result) in POLAR_TYPES or not isinstance(result, Iterable):
        # type is already something we support.
        # nothing to do
        yield Polar().to_polar(result)
    else:
        # iterate and return results
        for res in result:
            yield Polar().to_polar(res)


def to_external(polar_instance, env: Environment = None, **kwargs):
    """
    Convert `polar_instance` to external (Python) instance.
        1. Look in the `PYTHON_INSTANCE_CACHE`
        2. Check for user-defined `from_polar` method, if found use this
        3. If cache miss or `type` not a `CachingClass`, use Python class constructor
    """
    assert isinstance(polar_instance, ExternalInstance), "not a Polar Instance"
    cls = polar_instance.type
    assert isinstance(cls, ExternalClass), "not an external class"
    from_polar = cls.spec.from_polar
    source = cls.source_class
    try:
        return PYTHON_INSTANCE_CACHE[polar_instance.instance_cache_key] # type: ignore
    except (KeyError, AttributeError):
        # If there is no python instance in the cache,
        # make one with the default constructor.
        fields = {}
        for k, v in polar_instance.fields.items():
            if env:
                v = env.subst(v)
            fields[k] = convert_polar_types(v)
        if from_polar:
            return getattr(source, from_polar)(**fields)
        else:
            return source(**fields)

def convert_polar_types(expr):
    """ Convert Polar-specific types to Python types.
    Important if constructing Python instances from Polar."""
    if is_tuple(expr):
        return tuple((convert_polar_types(e) for e in expr))
    if is_dict(expr):
        return {convert_polar_types(k): convert_polar_types(v) for k, v in expr.items()}
    if isinstance(expr, Instance):
        return to_external(expr)
    if type(expr) in [str, int]:
        return expr
    if type(expr) == String or isinstance(expr, str):
        return super(type(expr), expr).__str__()
    if type(expr) == Number or isinstance(expr, int):
        return int(expr)
    if isinstance(expr, Variable):
        raise UnboundVariable(expr)
    if type(expr) == Boolean:
        return expr.val
    if expr is None:
        return expr
    raise PolarApiException(f"Couldn't convert type {type(expr)} to Python type")

@dataclass(unsafe_hash=True)
class ExternalClass(Specializer):
    name: str
    spec: ClassSpecification = field(default_factory=ClassSpecification)
    source_class: type = field(default_factory=type(object), hash=False)

    def make_instance(self, *args, **kwargs) -> 'ExternalInstance':
        """Instantiate the class."""
        return ExternalInstance(self, kwargs)

    def external_class(self):
        cls = EXTERNAL_CLASSES[self.spec.name]
        assert isinstance(cls, type), "not a Python class"
        return cls

    def is_subclass(self, other, **kwargs):
        return issubclass(self.external_class(), other.external_class())

    def is_applicable(self, arg, **kwargs):
        try:
            return issubclass(class_of(arg).external_class(), self.external_class())
        except AttributeError:
            return False

    def is_subspecializer(self, other, arg, *, env, **kwargs):
        """Adapted from `sub-specializer-p` in AMOP §1.8.1."""
        arg = env.subst(arg)
        mro = class_of(arg).external_class().__mro__
        return other.external_class() in mro[mro.index(self.external_class()):]

    def __repr__(self):
        return f"<{self.name}>"

    def __str__(self):
        return self.name

# naming `ExternalInstance` for consistency, can change to `ApplicationInstance`
# if/when we change everything over
@dataclass
class ExternalInstance(Instance):
    type: ExternalClass
    instance_cache_key: Optional[int] = None

    def __post_init__(self):
        # so doesn't call super post-init
        # TODO (leina): kill this once lazy field loading works
        return

    def map(self, f: Callable) -> 'ExternalInstance':
        """ Mapping method for type ExternalInstance"""
        copy = self.type.make_instance(**{k: map_tree(f, v) for k, v in self.fields.items()})
        copy.instance_cache_key = self.instance_cache_key
        return copy

    def get_field(self, field, args=None, **kwargs):
        """Call the external class corresponding to `self` for the `field`, with `args`"""
        # replace ExternalInstance with Python instance
        instance = instantiate_externals(self, **kwargs)
        args = instantiate_externals(args or [])

        # get attribute
        try:
            attr = getattr(instance, field)
        except AttributeError:
            raise PolarRuntimeException(f"{self} does not have field or method {field}")
        if isinstance(attr, MethodType):
            attr = attr(*args)

        gen = result_to_generator(attr)
        try:
            yield next(gen)
        except StopIteration:
            yield None

        yield from gen


class Http:
    """A resource accessed via HTTP."""
    def __init__(self, path="", query={}, hostname=None):
        self.path = path
        self.query = frozendict(query)
        if hostname:
            self.hostname = hostname

    def __repr__(self):
        return str(self)

    def __str__(self):
        q = {k: v for k, v in self.query.items()}
        host_str = f"hostname=\"{self.hostname}\"" if self.hostname else None
        path_str = f"path=\"{self.path}\"" if self.path != "" else None
        query_str = f"query={q}" if q != {} else None
        field_str = ", ".join(x for x in [host_str, path_str, query_str] if x)
        return f"Http({field_str})"

Polar().register_python_class(Http)

# wow hack
# using regex to regex template strings into regexes that we can use to regex urls into dicts
class PathMapper():
    """Map from a template string with capture groups of the form
    ``{name}`` to a dictionary of the form ``{name: captured_value}``

    :param template: the template string to match against
    """
    def __init__(self, template):
        capture_group = re.compile(r"({([^}]+)})")
        for outer, inner in capture_group.findall(template):
            if inner == "*":
                template = template.replace(outer, ".*")
            else:
                template = template.replace(outer, f"(?P<{inner}>[^/]+)")
        self.pattern = re.compile('^' + template + '$')

    def map(self, string):
        match = self.pattern.match(string)
        if match:
            yield match.groupdict()

Polar().register_python_class(PathMapper)

# WOW HACK
JWT_DECODE_KEYS: List[str] = []

class Jwt():
    """ Takes in a jwt and exposes the attributes as a dictionary"""
    # @TODO: Some way to pass in the key or something.
    def __init__(self, token):
        self.token = token
        self.attribs = None
        from authlib.jose import jwt # type: ignore
        for key in JWT_DECODE_KEYS:
            try:
                claims = jwt.decode(token, key)
                self.attribs = dict(claims)
                break
            except:
                pass

    def attributes(self):
        if self.attribs:
            yield self.attribs

Polar().register_python_class(Jwt)


########## EXPERIMENTAL ###############

class Slack:
    def __init__(self, format=None, events_url="http://localhost:5001/viz/events/"):
        self.format_str = format
        self.events_url = events_url

    def alert(self, d):
        try:
            import requests
            events = AuditLog().count()
            message = self.format_str.format(**d)
            message += "\n"
            message += f"Event: {self.events_url}{events}"
            webhook_url: str = "https://hooks.slack.com/services/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"
            logger.warn(f"Doing a slack alert {message}")
            request = requests.post(webhook_url, json={"text": message})
            if request.status_code != 200:
                logger.error(f"Something went wrong:\n{request}")
            return "ok"
        except Exception as e:
            logger.exception(e)
            pass

Polar().register_python_class(Slack)

def query_from_json(data: str):
    """Constructs a Query object from a JSON string"""

    def _convert_json(arg):
        if isinstance(arg, dict):
            if "class" in arg:
                return find_class(arg["class"]).make_instance(arg)
            else:
                return arg
        elif isinstance(arg, list):
            return list(map(self._convert_json, arg))
        else:
            return arg

    query_data = json.loads(data)
    try:
        args = list(map(_convert_json, query_data['args']))
        return Query(query_data['name'], args)
    except KeyError as e:
        raise PolarApiException("Key required: ", e)
