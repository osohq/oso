import string

from polar.exceptions import UnboundVariable
from polar.polar_types import is_tuple, copy_fact

class style:
    BLACK = lambda x: '\033[30m' + str(x)
    RED = lambda x: '\033[31m' + str(x)
    GREEN = lambda x: '\033[32m' + str(x)
    YELLOW = lambda x: '\033[33m' + str(x)
    BLUE = lambda x: '\033[34m' + str(x)
    MAGENTA = lambda x: '\033[35m' + str(x)
    CYAN = lambda x: '\033[36m' + str(x)
    WHITE = lambda x: '\033[37m' + str(x)
    UNDERLINE = lambda x: '\033[4m' + str(x)
    RESET = lambda x: '\033[0m' + str(x)


class DebugContext:
    COMMANDS = {
        "step": ("s",),
        "over": (),
        "out": (),
        "continue": ("c", "cont",),
        "var": ("v",),
        "stack": ("st",),
        "trace": ("t",),
        "bindings": ("bind",),
        "list": ("l",),
        "pdb": ()
    }

    HELP_TEXT = {
        "var": "var <var>"
    }

    def __init__(self):
        # The target stack for an over or out command.
        self._target_stack = None

        # The last command issued by the user
        self._last_command = None

        self._enabled = False

        self._command_map = {}
        for command_name, alternatives in self.COMMANDS.items():
            method_name = "_" + command_name

            assert command_name not in self._command_map
            self._command_map[command_name] = getattr(self, method_name)

            for alternative in alternatives:
                assert alternative not in self._command_map
                self._command_map[alternative] = getattr(self, method_name)

    def _reset_state(self):
        self._last_command = None
        self._target_stack = None

    def enable(self):
        self._reset_state()
        self._enabled = True

    def disable(self):
        self._enabled = False

    def _error(self, msg):
        self._print(msg)

    def _print(self, msg):
        print("  " + msg)

    def _get_command(self):
        commands = ", ".join(map(lambda cmd: self.HELP_TEXT.get(cmd, cmd), self.COMMANDS.keys()))

        command = input(style.YELLOW(f"({commands})") + style.RESET(": ")).strip()
        # Filter out empty strings
        parts = list(filter(lambda s: len(s) > 0,
                            map(lambda s: s.strip(), command.split(" "))))

        if not parts and self._last_command:
            return self._last_command

        try:
            func = self._command_map[parts[0]]
            args = parts[1:]
        except (KeyError, IndexError):
            self._error(f"Invalid command: {command}")
            return lambda _, __: False, ()

        self._last_command = (func, args)

        return func, args

    def _should_stop(self, query, env):
        if self._target_stack is None:
            return True

        stack = tuple(env.rule_stack)

        if len(stack) > len(self._target_stack):
            # We are deeper than the target
            return False

        for target, stack in zip(self._target_stack, stack):
            if target != stack:
                # Target and the current stack are not the same
                return False

        self._target_stack = None
        return True

    def debug_point(self, point_name, query, env):
        if not self._enabled:
            return

        if not self._should_stop(query, env):
            return

        try:
            current_expression = query[0]
        except IndexError:
            current_expression = ()

        self._print(f"{point_name}: {current_expression}")

        while True:
            command, args = self._get_command()
            if args:
                should_exit = command(query, env, args)
            else:
                should_exit = command(query, env)

            if should_exit:
                return

    def _step(self, query, env):
        return True

    def _continue(self, query, env):
        self.disable()
        return True

    def _pdb(self, query, env):
        import pdb; pdb.set_trace()
        return False

    def _bindings(self, query, env):
        for var in env.vars(include_temporary=True):
            try:
                self._print(f"{var} = {env[var]}")
            except UnboundVariable:
                self._print(f"{var} = UNBOUND")

        return False

    def _over(self, query, env):
        self._target_stack = tuple(env.rule_stack)
        return True

    def _out(self, query, env):
        self._target_stack = tuple(env.rule_stack)[:-1]
        return True

    def _list(self, query, env):
        try:
            current_expression = query[0]
        except IndexError:
            self._error("No query")
            return False

        try:
            code_context = current_expression.code_context
            if code_context.filename != '<input>':
                with open(code_context.filename) as f:
                    # Find correct line
                    for lineno, line in enumerate(f):
                        if lineno == code_context.lineno:
                            self._print(f"{code_context.filename}:{code_context.lineno}:{code_context.column}\n  " +
                                  line
                                  + "%*c" % (code_context.column + 3, '^'))
                            break
            else:
                self._print("<input>")
        except AttributeError:
            self._error("Missing code context")

        return False

    def _var(self, query, env, args=None):
        try:
            var = args[0]
        except (IndexError, TypeError):
            self._print(", ".join(map(str, env.vars(include_temporary=True))))
            return False

        try:
            if var[0] == "?":
                self._print("Hint: Variable should not start with ? in var.")
        except IndexError:
            pass

        try:
            self._print(f"{var} = {env[var]}")
        except UnboundVariable:
            self._print(f"Variable {var} not bound.")

        return False

    def _trace(self, query, env):
        try:
            current_expression = query[0]
        except IndexError:
            current_expression = ()

        for source in env.trace()[1:]: # skip the KB
            self._print(str(source[0] if is_tuple(source) else source))
        self._print(str(current_expression))

        return False

    def _stack(self, query, env):
        try:
            current_expression = query[0]
        except IndexError:
            current_expression = ()

        for source in env.rule_stack:
            self._print(str(source))

        self._print(str(current_expression))

        return False
